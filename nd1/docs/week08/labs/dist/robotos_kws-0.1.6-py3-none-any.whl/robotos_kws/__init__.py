"""robotos_kws: Edge AI Keyword Spotting SDK & CLI for RobotOS.

Provides high-level classes for dataset collection, DS-CNN training, int8 quantization,
and real-time voice command detection for PC and ESP32-S3 boards.
"""
from __future__ import annotations

import kws_common as _kc
from robotos_kws.audio import AudioRecorder, list_devices
from robotos_kws.board import Board
from robotos_kws.detector import Detector
from robotos_kws.trainer import Trainer

__version__ = "0.1.6"

from detect_board import auto_detect_port, detect_boards

# Public constants
KEYWORDS = _kc.KEYWORDS
LABELS = _kc.LABELS
SILENCE = _kc.SILENCE
UNKNOWN = _kc.UNKNOWN
SAMPLE_RATE = _kc.SAMPLE_RATE
CLIP_SAMPLES = _kc.CLIP_SAMPLES

# I/O helpers
read_wav = _kc.read_wav
write_wav = _kc.write_wav
rms_dbfs = _kc.rms_dbfs

__all__ = [
    "Detector",
    "Board",
    "AudioRecorder",
    "Trainer",
    "detect_boards",
    "auto_detect_port",
    "KEYWORDS",
    "LABELS",
    "SILENCE",
    "UNKNOWN",
    "SAMPLE_RATE",
    "CLIP_SAMPLES",
    "read_wav",
    "write_wav",
    "rms_dbfs",
    "list_devices",
    "__version__",
]
