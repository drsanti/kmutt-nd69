"""Programmatic Model Training and Evaluation for robotos_kws."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

import evaluate as eval_script
import train as train_script


class Trainer:
    """Manages DS-CNN training, int8 post-training quantization, and model benchmarking."""

    def __init__(self, data_dir: Union[str, Path] = "dataset", out_dir: Union[str, Path] = "artifacts"):
        self.data_dir = Path(data_dir)
        self.out_dir = Path(out_dir)

    def train(self, epochs: int = 40, batch: int = 64, augment: int = 2,
              width: int = 32, seed: int = 42) -> Dict[str, Any]:
        """Train the model and save artifacts (model.keras, model_float.tflite, model_int8.tflite, meta.json)."""
        args = [
            "--data", str(self.data_dir),
            "--out", str(self.out_dir),
            "--epochs", str(epochs),
            "--batch", str(batch),
            "--augment", str(augment),
            "--width", str(width),
            "--seed", str(seed),
        ]
        rc = train_script.main(args)
        if rc != 0:
            raise RuntimeError(f"Training failed with exit code {rc}")
        meta_path = self.out_dir / "meta.json"
        return json.loads(meta_path.read_text()) if meta_path.exists() else {}

    def evaluate(self, split: str = "test", device: Optional[str] = None) -> int:
        """Run evaluation on the test split and generate report.md."""
        args = [
            "--artifacts", str(self.out_dir),
            "--data", str(self.data_dir),
            "--split", split,
        ]
        if device:
            args.extend(["--device", device])
        return eval_script.main(args)
