#!/usr/bin/env python3
"""Flash prebuilt RobotOS firmware to ESP32-S3 boards (ws28p / es3c28p) with live progress.

Features:
- Smart auto-detection of ESP32-S3 serial ports across Windows, macOS (/dev/cu.*), and Linux.
- Automatic caching and on-demand download of prebuilt binaries from hardware-interface-workshop.
- Real-time unbuffered esptool progress (erasing, writing flash, percentages).
- Post-flash hardware telemetry verification (BoardInfo handshake and 50 Hz IMU check).

Usage:
    robotos-kws flash-firmware
    robotos-kws flash-firmware --board ws28p --port COM17
    robotos-kws flash-firmware --board es3c28p --port /dev/cu.usbmodem1101
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import List, Optional, Tuple

import serial.tools.list_ports

import wire

GITHUB_RAW_BASE = (
    "https://raw.githubusercontent.com/drsanti/hardware-interface-workshop/main/firmware-prebuilt"
)
FIRMWARE_FILES = [
    "flash_args",
    "bootloader.bin",
    "partition-table.bin",
    "robotos_board.bin",
]
BOARD_CAPS_MAP = {
    "ws28p": wire.CAP_IMU | wire.CAP_RTC | wire.CAP_BATT | wire.CAP_BTN,  # 0x3c
    "es3c28p": wire.CAP_LED | wire.CAP_MIC | wire.CAP_BTN | wire.CAP_BATT,  # 0x33
}


# ---------------------------------------------------------------------------
# 1. Serial Port Auto-Detection
# ---------------------------------------------------------------------------
def detect_esp32s3_port(preferred_port: Optional[str] = None) -> Tuple[str, str]:
    """Scan available serial ports and find the ESP32-S3 device."""
    ports = list(serial.tools.list_ports.comports())
    print("\n[1/4] Scanning Serial Ports...")

    if not ports:
        print("   [warning] No serial ports found on this system!")

    esp_candidates = []
    for p in ports:
        desc = p.description or "Unknown"
        hwid = p.hwid or ""
        is_esp = False

        # ESP32-S3 Native USB Serial/JTAG is VID 0x303A, PID 0x1001
        if p.vid == 0x303A and p.pid == 0x1001:
            is_esp = True
        elif p.vid == 0x303A:
            is_esp = True
        elif "303A:1001" in hwid or "USB Serial" in desc or "usbmodem" in p.device:
            is_esp = True

        tag = " [ESP32-S3 MATCH]" if is_esp else ""
        print(f"   • {p.device:<16} | {desc} (VID={hex(p.vid) if p.vid else 'None'}, PID={hex(p.pid) if p.pid else 'None'}){tag}")

        if is_esp:
            # On macOS, prefer /dev/cu.* over /dev/tty.*
            if sys.platform == "darwin" and p.device.startswith("/dev/tty."):
                cu_candidate = p.device.replace("/dev/tty.", "/dev/cu.")
                esp_candidates.append((cu_candidate, desc))
            else:
                esp_candidates.append((p.device, desc))

    if preferred_port:
        # Validate or normalize preferred port
        target = preferred_port
        if sys.platform == "darwin" and target.startswith("/dev/tty."):
            target = target.replace("/dev/tty.", "/dev/cu.")
            print(f"   -> [macOS] Converted '{preferred_port}' to callout device '{target}'")
        print(f"   -> Selected Port (user specified): {target}")
        return target, "User Specified"

    if not esp_candidates:
        print("\n[error] Could not automatically locate an ESP32-S3 board.")
        print("        Ensure your board is connected with a USB-C data cable (not charge-only).")
        print("        You can specify the port manually with: --port <PORT>")
        sys.exit(1)

    if len(esp_candidates) == 1:
        selected_port, selected_desc = esp_candidates[0]
        print(f"\n   ✓ Automatically selected ESP32-S3 on: {selected_port} ({selected_desc})")
        return selected_port, selected_desc

    print(f"\n   [info] Multiple ESP32-S3 devices detected ({len(esp_candidates)} found).")
    selected_port, selected_desc = esp_candidates[0]
    print(f"   -> Defaulting to first match: {selected_port} ({selected_desc})")
    print("      (To use a different port, pass --port <PORT>)")
    return selected_port, selected_desc


# ---------------------------------------------------------------------------
# 2. Firmware Provisioning & Caching with Visual Progress
# ---------------------------------------------------------------------------
def _format_size(num_bytes: int) -> str:
    """Format bytes into human-readable string."""
    if num_bytes >= 1_048_576:
        return f"{num_bytes / 1_048_576:.1f} MB"
    if num_bytes >= 1024:
        return f"{num_bytes / 1024:.1f} KB"
    return f"{num_bytes} B"


def _download_with_progress(url: str, dest_path: Path):
    """Download a file with live terminal progress bar."""
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = dest_path.with_suffix(dest_path.suffix + ".tmp")

    req = urllib.request.Request(url, headers={"User-Agent": "robotos-kws-flasher/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            total_size = int(response.headers.get("content-length", 0))
            downloaded = 0
            block_size = 16384
            last_percent = -1

            with open(temp_path, "wb") as f_out:
                while True:
                    chunk = response.read(block_size)
                    if not chunk:
                        break
                    f_out.write(chunk)
                    downloaded += len(chunk)

                    if total_size > 0:
                        percent = int((downloaded / total_size) * 100)
                        if percent != last_percent and (percent % 10 == 0 or percent == 100):
                            last_percent = percent
                            bar_len = 25
                            filled = int(bar_len * percent // 100)
                            bar = "=" * filled + "-" * (bar_len - filled)
                            sys.stdout.write(
                                f"\r     [{bar}] {percent:3d}% ({_format_size(downloaded)} / {_format_size(total_size)})"
                            )
                            sys.stdout.flush()

        if total_size > 0:
            sys.stdout.write("\n")
            sys.stdout.flush()
        temp_path.replace(dest_path)
    except Exception as e:
        if temp_path.exists():
            temp_path.unlink()
        raise RuntimeError(f"Failed to download from {url}: {e}") from e


def resolve_firmware_dir(board: str, user_dir: Optional[Path] = None) -> Path:
    """Find or download firmware files for the given board target."""
    print(f"\n[2/4] Resolving Prebuilt Firmware for board: '{board}'...")

    # Search candidates for existing local directories
    candidate_dirs = []
    if user_dir:
        candidate_dirs.append(user_dir.resolve())

    # Sibling local repository checks
    here = Path(__file__).resolve().parent
    workspace_root = here.parent.parent  # cronos root
    candidate_dirs.extend([
        workspace_root / "hardware-interface-workshop" / "firmware-prebuilt" / board,
        here.parent / "firmware-prebuilt" / board,
        Path.cwd() / "firmware-prebuilt" / board,
        Path.cwd() / "firmware" / board,
        Path.home() / ".robotos" / "firmware" / board,
    ])

    for c_dir in candidate_dirs:
        if c_dir.exists() and all((c_dir / f).exists() for f in FIRMWARE_FILES):
            print(f"   ✓ Found complete local firmware at: {c_dir}")
            for f in FIRMWARE_FILES:
                size = (c_dir / f).stat().st_size
                print(f"     • {f:<20} ({_format_size(size)}) [verified]")
            return c_dir

    # Fallback to user cache directory
    cache_dir = Path.home() / ".robotos" / "firmware" / board
    cache_dir.mkdir(parents=True, exist_ok=True)
    print(f"   Cache directory: {cache_dir}")

    for f_name in FIRMWARE_FILES:
        target_file = cache_dir / f_name
        if target_file.exists() and target_file.stat().st_size > 0:
            print(f"     • {f_name:<20} ({_format_size(target_file.stat().st_size)}) [cached]")
            continue

        file_url = f"{GITHUB_RAW_BASE}/{board}/{f_name}"
        print(f"   -> Fetching '{f_name}' from GitHub raw...")
        print(f"      Source: {file_url}")
        _download_with_progress(file_url, target_file)
        print(f"     • {f_name:<20} ({_format_size(target_file.stat().st_size)}) [downloaded]")

    return cache_dir


# ---------------------------------------------------------------------------
# 3. Flashing Execution via esptool with Live Progress
# ---------------------------------------------------------------------------
def run_esptool_flash(port: str, baud: int, firmware_dir: Path) -> int:
    """Execute esptool write_flash and stream progress output in real-time."""
    print(f"\n[3/4] Flashing Firmware to ESP32-S3 via esptool...")

    # Ensure esptool is installed in current Python environment
    try:
        import esptool
    except ImportError:
        print("   [info] 'esptool' not found in current Python environment.")
        print("          Installing 'esptool>=4.7' automatically via pip...")
        install_res = subprocess.run(
            [sys.executable, "-m", "pip", "install", "esptool>=4.7"],
            capture_output=True,
            text=True,
        )
        if install_res.returncode != 0:
            print(f"   [error] Automatic installation of esptool failed: {install_res.stderr}")
            print("           Please run manually: pip install esptool")
            return install_res.returncode
        print("   ✓ 'esptool' installed successfully!")

    print(f"   Target Port: {port}")
    print(f"   Baud Rate:   {baud}")
    print(f"   Flash Args:  {firmware_dir / 'flash_args'}")
    print("   ------------------------------------------------------------")

    # Command: python -m esptool --chip esp32s3 -p <PORT> -b <BAUD> write_flash "@flash_args"
    cmd = [
        sys.executable,
        "-u",  # Unbuffered stdout/stderr
        "-m",
        "esptool",
        "--chip",
        "esp32s3",
        "-p",
        port,
        "-b",
        str(baud),
        "write_flash",
        "@flash_args",
    ]

    # esptool resolves relative filenames from its current working directory
    process = subprocess.Popen(
        cmd,
        cwd=str(firmware_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    try:
        for line in iter(process.stdout.readline, ""):
            line_str = line.strip()
            if not line_str:
                continue
            # Format and display esptool progress lines nicely
            if "Writing at" in line_str or "Compressed" in line_str or "Erasing" in line_str:
                print(f"   [flash] {line_str}")
            elif "Connecting" in line_str or "Chip is" in line_str or "Features:" in line_str or "Crystal is" in line_str or "MAC:" in line_str:
                print(f"   [chip]  {line_str}")
            elif "Hash of data verified" in line_str or "Leaving..." in line_str or "Hard resetting" in line_str:
                print(f"   [done]  {line_str}")
            else:
                print(f"   {line_str}")
    except KeyboardInterrupt:
        process.kill()
        print("\n[warning] Flashing interrupted by user.")
        return 1

    process.wait()
    print("   ------------------------------------------------------------")
    if process.returncode != 0:
        print(f"\n[error] esptool failed with exit code {process.returncode}!")
        print("Troubleshooting tips:")
        print("1. Close any open serial monitors (Arduino IDE, VS Code, WebSerial tabs).")
        print("2. Unplug and replug the USB-C cable.")
        print("3. Try holding the BOOT button, press and release RESET, then retry flashing.")
        return process.returncode

    print("   ✓ Firmware written successfully! Board reset triggered.")
    return 0


# ---------------------------------------------------------------------------
# 4. Post-Flash Verification & Telemetry Handshake
# ---------------------------------------------------------------------------
def verify_board(port: str, board_model: str, timeout_s: float = 6.0) -> bool:
    """Connect to board, query BoardInfo, and verify live streaming."""
    print(f"\n[4/4] Verifying Board Telemetry Handshake...")
    print(f"   Waiting for board to finish booting on {port}...")
    time.sleep(1.5)  # Let bootloader and FreeRTOS initialize

    try:
        sess = wire.BoardSession.open(port, settle_s=2.0)
    except wire.WireError as e:
        print(f"   [warning] Could not open serial connection: {e}")
        return False

    try:
        expected_cap = wire.CAP_IMU if board_model == "ws28p" else wire.CAP_MIC
        info = sess.wait_board_info(timeout=timeout_s, need_cap=expected_cap, need_name="flash_firmware.py")

        print("\n   ✓ Board Telemetry Verified:")
        print(f"     • Hardware Model:  {board_model}")
        print(f"     • Firmware ID:     {info.fw_version or 'robotos-fw'}")
        print(f"     • Capabilities:    {wire.caps_str(info.caps)}")
        if info.uuid:
            print(f"     • Board UUID:      {info.uuid}")

        if board_model == "ws28p":
            print("\n   Checking live 50 Hz IMU telemetry stream for 1.5 seconds...")
            accel_samples = []
            start_t = time.monotonic()
            while time.monotonic() - start_t < 1.5:
                for f in sess.poll(0.05):
                    if f.msg_type == wire.MSG_IMU:
                        imu = wire.decode_imu(f.payload)
                        accel_samples.append(imu.accel)
            if accel_samples:
                mean_mag = sum(
                    (a[0] ** 2 + a[1] ** 2 + a[2] ** 2) ** 0.5 for a in accel_samples
                ) / len(accel_samples)
                rate = len(accel_samples) / 1.5
                print(f"     • Telemetry rate:  {rate:.1f} Hz ({len(accel_samples)} frames received)")
                print(f"     • Accel magnitude: |a| = {mean_mag:.2f} m/s² (expect ~9.8 m/s² stationary)")
                print("     ✓ IMU 6-DOF sensor is active and streaming cleanly!")
            else:
                print("     [warning] No IMU frames received during test window.")

        return True
    except wire.WireError as e:
        print(f"   [warning] Telemetry handshake timed out: {e}")
        return False
    finally:
        sess.close()


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------
def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="robotos-kws flash-firmware",
        description="Flash prebuilt RobotOS firmware to ESP32-S3 boards (ws28p / es3c28p) with live progress.",
    )
    parser.add_argument(
        "--board",
        choices=["ws28p", "es3c28p"],
        default="ws28p",
        help="Target board variant: ws28p (IMU+RTC, default) or es3c28p (LED+MIC)",
    )
    parser.add_argument("--port", help="Serial port (auto-detects ESP32-S3 if omitted)")
    parser.add_argument(
        "--baud",
        type=int,
        default=460800,
        help="Flashing baud rate (default: 460800, use 115200 if cable is unstable)",
    )
    parser.add_argument("--firmware-dir", type=Path, help="Local directory containing prebuilt firmware files")
    parser.add_argument("--no-verify", action="store_true", help="Skip post-flash telemetry handshake verification")
    args = parser.parse_args(argv)

    print("============================================================")
    print(" RobotOS ESP32-S3 Firmware Flasher (Multi-Track)")
    print("============================================================")

    # 1. Detect port
    port, desc = detect_esp32s3_port(args.port)

    # 2. Resolve firmware
    try:
        fw_dir = resolve_firmware_dir(args.board, args.firmware_dir)
    except Exception as e:
        print(f"\n[error] Firmware preparation failed: {e}")
        return 1

    # 3. Flash firmware
    flash_rc = run_esptool_flash(port, args.baud, fw_dir)
    if flash_rc != 0:
        return flash_rc

    # 4. Verify telemetry
    if not args.no_verify:
        verified = verify_board(port, args.board)
        if not verified:
            print("\n[notice] Flashing finished, but automated handshake timed out.")
            print("         You can test manually with: robotos-kws check-imu --port " + port)
            return 0

    print("\n============================================================")
    print(f" SUCCESS: Board '{args.board}' on {port} is ready for labs!")
    print("============================================================")
    return 0


if __name__ == "__main__":
    sys.exit(main())
