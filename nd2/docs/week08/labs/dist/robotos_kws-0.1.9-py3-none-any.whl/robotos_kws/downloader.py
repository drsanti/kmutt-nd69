"""robotos download: Zero-dependency folder extraction from GitHub repositories.

Supports downloading specific folders from GitHub repositories (e.g. course labs,
starter templates) without downloading the entire repository or requiring git.
"""
from __future__ import annotations

import argparse
import io
import os
import re
import shutil
import subprocess
import sys
import tarfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import List, Optional, Tuple

# Default university course repository
DEFAULT_COURSE_OWNER = "drsanti"
DEFAULT_COURSE_REPO = "kmutt-nd69"
DEFAULT_BRANCH = "main"

GITHUB_TREE_RE = re.compile(
    r"^https?://github\.com/([^/]+)/([^/]+)/tree/([^/]+)/(.*)/?$"
)
GITHUB_REPO_RE = re.compile(
    r"^https?://github\.com/([^/]+)/([^/]+)/?$"
)
SHORTHAND_TRACK_WEEK_RE = re.compile(
    r"^(?:kmutt:)?(nd[123])/week0?(\d+)/?$", re.IGNORECASE
)


def parse_target(target: str, default_branch: str = DEFAULT_BRANCH) -> Tuple[str, str, str, str, str]:
    """Parse a GitHub URL or course shorthand into (owner, repo, branch, subpath, default_folder_name)."""
    target = target.strip()

    # 1. Check KMUTT track shorthand (e.g. "nd3/week08" or "kmutt:nd3/week8")
    m = SHORTHAND_TRACK_WEEK_RE.match(target)
    if m:
        track = m.group(1).lower()
        week_num = int(m.group(2))
        week_str = f"week{week_num:02d}"
        subpath = f"{track}/docs/{week_str}"
        return (
            DEFAULT_COURSE_OWNER,
            DEFAULT_COURSE_REPO,
            default_branch,
            subpath,
            week_str,
        )

    # 2. Check full GitHub tree URL (e.g. "https://github.com/owner/repo/tree/branch/sub/path")
    m = GITHUB_TREE_RE.match(target)
    if m:
        owner = m.group(1)
        repo = m.group(2)
        branch = m.group(3)
        subpath = m.group(4).rstrip("/")
        default_folder = Path(subpath).name or repo
        return owner, repo, branch, subpath, default_folder

    # 3. Check GitHub root repo URL
    m = GITHUB_REPO_RE.match(target)
    if m:
        owner = m.group(1)
        repo = m.group(2).removesuffix(".git")
        return owner, repo, default_branch, "", repo

    # 4. Check "owner/repo/path" or "owner/repo" shorthand
    parts = target.split("/")
    if len(parts) >= 2:
        owner = parts[0]
        repo = parts[1]
        subpath = "/".join(parts[2:]).rstrip("/") if len(parts) > 2 else ""
        default_folder = Path(subpath).name if subpath else repo
        return owner, repo, default_branch, subpath, default_folder

    raise ValueError(
        f"Unrecognized target: '{target}'\n\n"
        "Supported formats:\n"
        "  1. Course shorthand : nd3/week08  (or nd1/week08, nd2/week08)\n"
        "  2. Full GitHub URL  : https://github.com/drsanti/kmutt-nd69/tree/main/nd3/docs/week08\n"
        "  3. Repo path        : owner/repo/path/to/folder"
    )


def download_via_tarball(
    owner: str,
    repo: str,
    branch: str,
    subpath: str,
    dest_dir: Path,
) -> int:
    """Stream GitHub codeload archive and extract only matching subpath files."""
    tarball_url = f"https://codeload.github.com/{owner}/{repo}/tar.gz/refs/heads/{branch}"
    print(f"[robotos] Connecting to GitHub ({owner}/{repo} @ {branch})...")

    req = urllib.request.Request(
        tarball_url,
        headers={
            "User-Agent": "robotos-cli/0.1.8",
            "Accept": "application/x-gzip",
        },
    )

    try:
        response = urllib.request.urlopen(req, timeout=30)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise RuntimeError(
                f"Repository or branch not found: '{owner}/{repo}' (branch '{branch}')"
            ) from e
        raise RuntimeError(f"GitHub returned HTTP error {e.code}: {e.reason}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error connecting to GitHub: {e.reason}") from e

    dest_dir.mkdir(parents=True, exist_ok=True)
    norm_subpath = subpath.strip("/").replace("\\", "/")

    extracted_files = 0
    total_bytes = 0

    print(f"[robotos] Extracting '{subpath or repo}' into {dest_dir}...")

    # Read and decompress streaming tarball
    with tarfile.open(fileobj=response, mode="r|gz") as tar:
        for member in tar:
            # GitHub tarball top directory is '{repo}-{branch}/...'
            parts = member.name.split("/", 1)
            if len(parts) < 2:
                continue
            path_in_repo = parts[1]

            # Check if this member is inside the requested subpath
            if norm_subpath:
                if not (path_in_repo == norm_subpath or path_in_repo.startswith(norm_subpath + "/")):
                    continue
                # Calculate relative path inside target folder
                rel_path = path_in_repo[len(norm_subpath):].lstrip("/")
            else:
                rel_path = path_in_repo

            if not rel_path:
                continue

            target_path = dest_dir / rel_path

            if member.isdir():
                target_path.mkdir(parents=True, exist_ok=True)
            elif member.isreg():
                target_path.parent.mkdir(parents=True, exist_ok=True)
                fileobj = tar.extractfile(member)
                if fileobj:
                    with open(target_path, "wb") as f_out:
                        shutil.copyfileobj(fileobj, f_out)
                    extracted_files += 1
                    total_bytes += member.size

    if extracted_files == 0:
        raise RuntimeError(
            f"No files matched path '{subpath}' in repository '{owner}/{repo}' ({branch})."
        )

    size_mb = total_bytes / (1024 * 1024)
    print(f"[robotos] Successfully extracted {extracted_files} files ({size_mb:.2f} MB).")
    return extracted_files


def download_via_git_sparse(
    owner: str,
    repo: str,
    branch: str,
    subpath: str,
    dest_dir: Path,
) -> int:
    """Clone only the subfolder using git sparse-checkout."""
    repo_url = f"https://github.com/{owner}/{repo}.git"
    print(f"[robotos] Initializing Git sparse-checkout for {repo_url}...")

    dest_dir.mkdir(parents=True, exist_ok=True)

    # 1. git clone --sparse
    cmd_clone = [
        "git", "clone", "--depth", "1", "--filter=blob:none", "--sparse",
        "--branch", branch, repo_url, str(dest_dir)
    ]
    rc = subprocess.run(cmd_clone)
    if rc.returncode != 0:
        raise RuntimeError("Git sparse clone failed.")

    # 2. git sparse-checkout set
    if subpath:
        cmd_sparse = ["git", "-C", str(dest_dir), "sparse-checkout", "set", subpath]
        rc = subprocess.run(cmd_sparse)
        if rc.returncode != 0:
            raise RuntimeError("Git sparse-checkout set failed.")

    print(f"[robotos] Git sparse repository initialized in {dest_dir}.")
    return 1


def print_next_steps(dest_dir: Path) -> None:
    """Print context-aware instructions for the student."""
    print("\n" + "=" * 65)
    print(" [robotos] Setup Complete! Next steps:")
    print("=" * 65)

    labs_dir = dest_dir / "labs"
    target_work_dir = labs_dir if labs_dir.exists() else dest_dir

    print(f"  1. Navigate to your lab folder:")
    print(f"     cd {target_work_dir}")
    print()
    print(f"  2. Create and activate a Python 3.11 virtual environment:")
    print(f"     # Windows (PowerShell):")
    print(f"     py -3.11 -m venv .venv")
    print(f"     .\\.venv\\Scripts\\Activate.ps1")
    print(f"     # macOS / Linux:")
    print(f"     python3.11 -m venv .venv")
    print(f"     source .venv/bin/activate")
    print()

    req_file = target_work_dir / "requirements.txt"
    if req_file.exists():
        print(f"  3. Install dependencies:")
        print(f"     pip install -r requirements.txt")
        print()

    print(f"  4. Verify your ESP32-S3 board connection:")
    print(f"     robotos detect")
    print(f"     robotos check-imu")
    print("=" * 65 + "\n")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="robotos download",
        description="Download labs, starter templates, or folders from GitHub without cloning entire repos.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Course shorthand (KMUTT ND69):
  robotos download nd3/week08
  robotos download nd1/week08
  robotos download nd2/week08

  # Full GitHub tree URL:
  robotos download https://github.com/drsanti/kmutt-nd69/tree/main/nd3/docs/week08

  # Custom output directory:
  robotos download nd3/week08 -o my_robotics_lab

  # Git-linked sparse checkout (allows 'git pull' later):
  robotos download nd3/week08 --git
        """,
    )
    parser.add_argument(
        "target",
        help="GitHub URL (https://github.com/...) or course shorthand (e.g. nd3/week08)",
    )
    parser.add_argument(
        "-o", "--out",
        default=None,
        help="Destination directory (defaults to folder name, e.g. ./week08)",
    )
    parser.add_argument(
        "--branch",
        default=DEFAULT_BRANCH,
        help=f"Git branch (default: {DEFAULT_BRANCH})",
    )
    parser.add_argument(
        "--git",
        action="store_true",
        help="Use Git sparse-checkout instead of pure-Python zip extraction",
    )

    args = parser.parse_args(argv)

    try:
        owner, repo, branch, subpath, default_folder = parse_target(
            args.target, default_branch=args.branch
        )
    except ValueError as e:
        print(f"[ERROR] {e}")
        return 1

    dest_dir = Path(args.out) if args.out else Path(default_folder)

    try:
        if args.git:
            download_via_git_sparse(owner, repo, branch, subpath, dest_dir)
        else:
            download_via_tarball(owner, repo, branch, subpath, dest_dir)
    except RuntimeError as e:
        print(f"[ERROR] {e}")
        return 2
    except KeyboardInterrupt:
        print("\n[robotos] Download cancelled by user.")
        return 130

    print_next_steps(dest_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
