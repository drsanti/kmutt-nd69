"""Zero-dependency Polyphonic Drum Synthesizer for robotos_kws.

Synthesizes studio-quality percussion waveforms in real-time memory using NumPy
and streams them via sounddevice with low latency, polyphony, and soft limiting.
"""
from __future__ import annotations

import math
import threading
import time
from typing import List, Optional

import numpy as np

try:
    import sounddevice as sd
except ImportError:
    sd = None

try:
    import robotos_rs as _native
    HAS_RUST_CORE = True
except ImportError:
    _native = None
    HAS_RUST_CORE = False


ASCII_BANNER = """
================================================================================
           AIR DRUM & MOTION MUSIC SYNTHESIZER (ESP32-S3 IMU)
================================================================================
"""

ASCII_DRUM_KIT = """
  +--------------------------- AIR DRUM KIT ---------------------------+
  |                                                                    |
  |     [CRASH]                  (HI-HAT)                   [RIDE]     |
  |      {crash_pad}                       {hihat_pad}                     {ride_pad}     |
  |                                                                    |
  |               [SNARE]                        [TOM]                 |
  |                {snare_pad}                          {tom_pad}                |
  |                                                                    |
  |                               (KICK)                               |
  |                                {kick_pad}                                |
  |                                                                    |
  +--------------------------------------------------------------------+
"""


def render_drum_kit(hit_sound: Optional[str] = None) -> str:
    """Render an ASCII drum kit showing which pad was struck."""
    def pad(name: str, symbol: str = "O") -> str:
        if hit_sound == name:
            return f"[{symbol * 3}]"
        return f" {symbol} "

    return ASCII_DRUM_KIT.format(
        crash_pad=pad("crash", "*"),
        hihat_pad=pad("hihat", "#") if hit_sound != "open_hh" else pad("open_hh", "="),
        ride_pad=pad("cowbell", "@"),
        snare_pad=pad("snare", "X"),
        tom_pad=pad("tom", "o"),
        kick_pad=pad("kick", "O"),
    )


class DrumPolySynth:
    """Polyphonic drum synthesizer generating percussion waveforms in real-time."""

    def __init__(self, sample_rate: int = 44100):
        if sd is None:
            raise RuntimeError("sounddevice is not installed. Run 'pip install sounddevice'")
        self.fs = sample_rate
        self.lock = threading.Lock()
        self.active_voices: List[List] = []  # [samples_array, current_index, volume]
        self._init_waveforms()

        self.stream = sd.OutputStream(
            samplerate=self.fs,
            channels=1,
            blocksize=256,
            callback=self._audio_callback,
        )
        self.stream.start()

    def _audio_callback(self, outdata, frames, time_info, status):
        outdata.fill(0)
        buf = np.zeros(frames, dtype=np.float32)
        with self.lock:
            remaining = []
            for voice in self.active_voices:
                data, idx, vol = voice
                chunk_len = min(frames, len(data) - idx)
                if chunk_len > 0:
                    buf[:chunk_len] += data[idx:idx + chunk_len] * vol
                    idx += chunk_len
                    if idx < len(data):
                        remaining.append([data, idx, vol])
            self.active_voices = remaining
        # Soft limiter / saturation to avoid harsh digital clipping
        outdata[:, 0] = np.tanh(buf)

    def _init_waveforms(self):
        fs = self.fs

        # 1. KICK DRUM: Punchy exponential pitch sweep 160 Hz -> 42 Hz with sub-bass weight
        if _native is not None:
            try:
                self.kick = np.array(_native.synthesize_waveform("kick", int(fs)), dtype=np.float32)
            except Exception:
                self.kick = None
        else:
            self.kick = None

        if self.kick is None:
            t_kick = np.linspace(0, 0.28, int(fs * 0.28), False)
            f_kick = 42.0 + 118.0 * np.exp(-t_kick * 32.0)
            phase_kick = 2 * np.pi * np.cumsum(f_kick) / fs
            env_kick = np.exp(-t_kick * 13.0)
            click = np.sin(2 * np.pi * 300 * t_kick[:int(fs * 0.015)]) * np.linspace(1, 0, int(fs * 0.015))
            kick_buf = np.sin(phase_kick) * env_kick
            kick_buf[:len(click)] += click * 0.4
            self.kick = np.clip(kick_buf * 1.1, -1.0, 1.0).astype(np.float32)

        # 2. SNARE DRUM: Tuned drum body (185 Hz) + crisp filtered noise envelope
        t_snare = np.linspace(0, 0.22, int(fs * 0.22), False)
        body = np.sin(2 * np.pi * 185 * t_snare) * np.exp(-t_snare * 24.0)
        noise = np.random.uniform(-1, 1, len(t_snare))
        noise[1:] = noise[1:] - 0.70 * noise[:-1]
        noise_env = np.exp(-t_snare * 17.0)
        self.snare = (body * 0.55 + noise * noise_env * 0.65).astype(np.float32)

        # 3. CLOSED HI-HAT: Ultra-crisp high frequency metallic sizzle (60 ms)
        t_hh = np.linspace(0, 0.065, int(fs * 0.065), False)
        hh_noise = np.random.uniform(-1, 1, len(t_hh))
        hh_noise[1:] = hh_noise[1:] - 0.88 * hh_noise[:-1]
        self.hihat = (hh_noise * np.exp(-t_hh * 55.0) * 0.65).astype(np.float32)

        # 4. OPEN HI-HAT: Sustained metallic sizzle (350 ms)
        t_oh = np.linspace(0, 0.35, int(fs * 0.35), False)
        oh_noise = np.random.uniform(-1, 1, len(t_oh))
        oh_noise[1:] = oh_noise[1:] - 0.85 * oh_noise[:-1]
        self.open_hh = (oh_noise * np.exp(-t_oh * 11.0) * 0.60).astype(np.float32)

        # 5. CRASH CYMBAL: Multi-sine inharmonic metallic clusters + noise shimmer (1.4 s)
        t_cr = np.linspace(0, 1.4, int(fs * 1.4), False)
        freqs = [587, 845, 1175, 1480, 2120]
        sines = np.zeros_like(t_cr)
        for f in freqs:
            sines += np.sin(2 * np.pi * f * t_cr + np.random.uniform(0, 2 * np.pi))
        sines /= len(freqs)
        cr_noise = np.random.uniform(-1, 1, len(t_cr))
        cr_noise[1:] = cr_noise[1:] - 0.75 * cr_noise[:-1]
        cr_env = np.exp(-t_cr * 3.2)
        self.crash = ((sines * 0.35 + cr_noise * 0.45) * cr_env).astype(np.float32)

        # 6. TOM DRUM: Resonant pitch-bending body (140 Hz -> 70 Hz)
        t_tom = np.linspace(0, 0.32, int(fs * 0.32), False)
        f_tom = 70.0 + 70.0 * np.exp(-t_tom * 16.0)
        phase_tom = 2 * np.pi * np.cumsum(f_tom) / fs
        self.tom = (np.sin(phase_tom) * np.exp(-t_tom * 9.5) * 0.9).astype(np.float32)

        # 7. COWBELL: Classic 808 dual square pulse (587 Hz & 845 Hz)
        if _native is not None:
            try:
                self.cowbell = np.array(_native.synthesize_waveform("cowbell", int(fs)), dtype=np.float32)
            except Exception:
                self.cowbell = None
        else:
            self.cowbell = None

        if self.cowbell is None:
            t_cb = np.linspace(0, 0.18, int(fs * 0.18), False)
            cb1 = np.sign(np.sin(2 * np.pi * 587 * t_cb))
            cb2 = np.sign(np.sin(2 * np.pi * 845 * t_cb))
            cb_env = np.exp(-t_cb * 19.0)
            self.cowbell = ((cb1 + cb2) * 0.35 * cb_env).astype(np.float32)

    def play(self, sound_name: str, volume: float = 1.0):
        """Trigger playback of a synthesized percussion voice with dynamic velocity."""
        snd = getattr(self, sound_name, None)
        if snd is not None:
            vol = float(np.clip(volume, 0.1, 1.0))
            with self.lock:
                self.active_voices.append([snd, 0, vol])

    def close(self):
        """Stop and close the PortAudio output stream."""
        try:
            self.stream.stop()
            self.stream.close()
        except Exception:
            pass


def run_sound_check_demo(synth: Optional[DrumPolySynth] = None) -> None:
    """Run built-in rock groove sound check demonstrating all percussion voices."""
    created = False
    if synth is None:
        synth = DrumPolySynth()
        created = True

    try:
        print(ASCII_BANNER)
        print("Running Built-In Air Drum Sound Check Demo...")
        print(render_drum_kit())

        patterns = [
            ("kick", 1.0, 0.25),
            ("hihat", 0.7, 0.25),
            ("snare", 0.95, 0.25),
            ("hihat", 0.7, 0.25),
            ("kick", 0.9, 0.125),
            ("kick", 1.0, 0.125),
            ("snare", 1.0, 0.25),
            ("tom", 0.85, 0.15),
            ("tom", 0.95, 0.15),
            ("crash", 1.0, 0.60),
            ("cowbell", 0.85, 0.25),
            ("cowbell", 0.95, 0.35),
        ]

        for snd, vol, delay in patterns:
            print(f"  [Demo Voice] Playing {snd.upper():<8} (Vol: {vol * 100:3.0f}%)")
            synth.play(snd, vol)
            time.sleep(delay)

        print("\n[Demo Complete] All percussion sound engines verified successfully!")
    finally:
        if created:
            synth.close()
