"""robotos: Hardware & Board Interaction CLI for RobotOS.

Provides dedicated commands for ESP32-S3 microcontroller board interaction,
wire protocol diagnostics, firmware flashing, and hardware sensor telemetry.
Machine learning and KWS commands belong to 'robotos-kws'.
"""
from __future__ import annotations

import argparse
import sys
from typing import List, Optional

import collect
import collect_imu
import detect_board
import flash_firmware
import wire
from robotos_kws.audio import print_devices
import robotos_kws.downloader as downloader


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="robotos",
        description="robotos: Hardware & Board Interaction CLI for RobotOS",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Hardware & Board Interaction Examples:
  # Auto-detect connected boards and test wire protocol handshake:
  robotos detect
  robotos detect --json

  # Flash workshop firmware to ESP32-S3 boards:
  robotos flash-firmware
  robotos flash-firmware --board ws28p --port COM17
  robotos flash-firmware --board es3c28p

  # Inspect live hardware telemetry:
  robotos check-imu                 # 50 Hz QMI8658 IMU stream (ws28p)
  robotos check-imu --port COM17
  robotos check-board               # Live mic dBFS meter (es3c28p)
  robotos check-board --gain 80

  # Download labs & starter templates from GitHub:
  robotos download nd3/week08
  robotos download https://github.com/drsanti/kmutt-nd69/tree/main/nd3/docs/week08

  # Host audio devices:
  robotos devices

Note: For Machine Learning, dataset recording, model training, and KWS inference,
use the dedicated ML toolkit: robotos-kws (e.g. robotos-kws train-imu, robotos-kws live-imu).
        """,
    )
    subparsers = parser.add_subparsers(dest="command", title="Board & Hardware Subcommands", required=True)

    # 0. download / clone
    subparsers.add_parser(
        "download",
        aliases=["clone", "get", "pull"],
        help="Download labs, starter templates, or folders from GitHub without cloning entire repos",
        add_help=False,
    )

    # 1. detect
    subparsers.add_parser(
        "detect",
        aliases=["detect-board", "boards", "scan"],
        help="Auto-detect connected ESP32-S3 boards and verify wire protocol handshake",
        add_help=False,
    )

    # 2. flash-firmware
    subparsers.add_parser(
        "flash-firmware",
        aliases=["flash"],
        help="Flash prebuilt ESP32-S3 firmware (ws28p/es3c28p) with live progress",
        add_help=False,
    )

    # 3. check-imu
    p_check_imu = subparsers.add_parser(
        "check-imu",
        help="Check ws28p board connection and live 50 Hz IMU telemetry (gravity & gyro drift)",
    )
    p_check_imu.add_argument("--port", default=None, help="Serial port (auto-detects ws28p if omitted)")

    # 4. check-board
    p_check = subparsers.add_parser(
        "check-board",
        help="Check ESP32-S3 board connection and live mic dBFS meter",
    )
    p_check.add_argument("--port", default=None, help="Serial port (auto-detects es3c28p if omitted)")
    p_check.add_argument("--gain", type=int, default=80, help="Mic gain 0-100%% (default 80)")

    # 5. devices
    subparsers.add_parser("devices", help="List host audio devices on this computer")

    return parser


# Machine learning / KWS subcommands that belong to robotos-kws
ML_KWS_COMMANDS = {
    "collect-imu", "collect-board", "collect-pc", "train", "train-imu",
    "evaluate", "live-pc", "live-board", "live-imu", "export", "verify-c", "synth-data", "synth"
}


def main(argv: Optional[List[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = create_parser()
    if not argv:
        parser.print_help()
        return 0

    cmd = argv[0]
    sub_args = argv[1:]

    if cmd in ("-h", "--help"):
        parser.print_help()
        return 0

    # Clean separation: If an ML/KWS command was given to robotos, notify the user and forward
    if cmd in ML_KWS_COMMANDS:
        print(f"[notice] '{cmd}' is a Machine Learning / KWS command.")
        print(f"         Running via 'robotos-kws {cmd}'...\n")
        import robotos_kws.cli as kws_cli
        return kws_cli.main(argv)

    if cmd in ("download", "clone", "get", "pull"):
        return downloader.main(sub_args)
    elif cmd in ("detect", "detect-board", "boards", "scan"):
        return detect_board.main(sub_args)
    elif cmd in ("flash-firmware", "flash"):
        return flash_firmware.main(sub_args)
    elif cmd == "check-imu":
        p = argparse.ArgumentParser(prog="robotos check-imu")
        p.add_argument("--port", default=None)
        parsed = p.parse_args(sub_args)
        port = parsed.port
        if not port:
            try:
                port = detect_board.auto_detect_port(need_cap=wire.CAP_IMU, preferred_model="ws28p")
            except RuntimeError as e:
                print(f"[ERROR] {e}")
                return 2
        return collect_imu.main(["--port", port, "--check"])
    elif cmd == "check-board":
        p = argparse.ArgumentParser(prog="robotos check-board")
        p.add_argument("--port", default=None)
        p.add_argument("--gain", type=int, default=80)
        parsed = p.parse_args(sub_args)
        port = parsed.port
        if not port:
            try:
                port = detect_board.auto_detect_port(need_cap=wire.CAP_MIC, preferred_model="es3c28p")
            except RuntimeError as e:
                print(f"[ERROR] {e}")
                return 2
        return collect.main(["--port", port, "--gain", str(parsed.gain), "--info"])
    elif cmd == "devices":
        print_devices()
        return 0
    else:
        print(f"[robotos] Unknown command: {cmd}")
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
