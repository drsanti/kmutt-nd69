from robotos_edge.cli.edge_cli import main

if __name__ == "__main__":
    raise SystemExit(main())
