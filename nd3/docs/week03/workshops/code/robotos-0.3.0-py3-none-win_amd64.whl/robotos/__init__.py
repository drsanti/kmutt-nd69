"""robotos — Python SDK over the stable C ABI (ADR-0018).

```python
import robotos
from robotos.messages.robotos.sensor.v1.imu_pb2 import Imu

with robotos.Node("py_demo") as node:
    pub = node.create_publisher("/robot/01/sensor/imu", Imu)
    pub.publish(Imu(x=1.0, y=2.0, z=3.0))
```
"""

from .errors import RobotosError, STATUS_NAMES
from .node import Node, Publisher, Subscriber, WAIT_FOREVER
from .presence import PresenceToken, PresenceWatcher
from .service import Service
from .action import ActionServer, ActionClient, GoalStatus
from .record import Recorder, bag_info

__all__ = [
    "Node", "Publisher", "Subscriber", "Service",
    "ActionServer", "ActionClient", "GoalStatus",
    "Recorder", "bag_info",
    "PresenceToken", "PresenceWatcher",
    "RobotosError", "STATUS_NAMES", "WAIT_FOREVER",
]

__version__ = "0.3.0"
