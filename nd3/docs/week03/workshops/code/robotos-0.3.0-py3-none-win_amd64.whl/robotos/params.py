"""Parameters — scalar declare/get/set + remote-set opt-in (ADR 0011).

Typed ABI: declare/get/set per i64/f64/bool/string. `declare_parameter`
dispatches on the Python type; `param_get` probes the four types when
no `kind` is given.
"""

from __future__ import annotations

import ctypes
from typing import Optional

from . import _ffi
from .errors import check

_KINDS = ("i64", "f64", "bool", "string")


def _kind_of(value) -> str:
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "i64"
    if isinstance(value, float):
        return "f64"
    if isinstance(value, str):
        return "string"
    raise TypeError(f"unsupported param type: {type(value).__name__}")


def _descriptor(
    description: str, read_only: bool, value_range,
) -> ctypes.pointer:
    d = _ffi.ParamDescriptor(
        struct_size=ctypes.sizeof(_ffi.ParamDescriptor),
        description=description.encode(),
        read_only=1 if read_only else 0,
        has_range=1 if value_range else 0,
        range_min=value_range[0] if value_range else 0.0,
        range_max=value_range[1] if value_range else 0.0,
    )
    return ctypes.pointer(d)


def declare(
    node, name: str, value, description: str = "",
    read_only: bool = False, value_range=None,
) -> None:
    kind = _kind_of(value)
    desc = _descriptor(description, read_only, value_range)
    v = value.encode() if kind == "string" else value
    check(
        getattr(_ffi, f"robotos_param_declare_{kind}")(
            node._handle, name.encode(), v, desc),
        f"declare_parameter {name}")


def get(node, name: str, kind: Optional[str] = None):
    """Probe all four scalar types when `kind` is omitted — NOT_FOUND
    only propagates if none match."""
    for k in ([kind] if kind else _KINDS):
        if k == "string":
            buf = ctypes.create_string_buffer(1024)
            out_len = ctypes.c_size_t(0)
            st = _ffi.robotos_param_get_string(
                node._handle, name.encode(), buf, 1024,
                ctypes.byref(out_len))
            if st == 0:
                return buf.value.decode()
        else:
            ct = {"i64": ctypes.c_int64, "f64": ctypes.c_double,
                  "bool": ctypes.c_int32}[k]
            out = ct(0)
            st = getattr(_ffi, f"robotos_param_get_{k}")(
                node._handle, name.encode(), ctypes.byref(out))
            if st == 0:
                return bool(out.value) if k == "bool" else out.value
        if st != 1:                       # != INVALID_ARGUMENT → real error
            check(st, f"param_get {name}")
    check(st, f"param_get {name}")


def set_(node, name: str, value) -> None:
    kind = _kind_of(value)
    v = value if kind != "string" else value.encode()
    check(
        getattr(_ffi, f"robotos_param_set_{kind}")(
            node._handle, name.encode(), v),
        f"param_set {name}")
