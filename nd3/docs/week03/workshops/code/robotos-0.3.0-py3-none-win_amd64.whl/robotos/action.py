"""Actions — long-running goals with feedback (ADR 0009).

Same marshalling pattern as services: the trampoline posts the goal
to a daemon pump thread and blocks on an Event; the pump runs the
user handler (free to call robotos APIs). `GoalCtx` forwards the
ctx-scoped FFI calls — they must happen INSIDE the handler window,
which the pump guarantees (the trampoline waits for it).
"""

from __future__ import annotations

import ctypes
import enum
import queue
import threading
from typing import Any, Callable, Optional

from . import _ffi
from .errors import RobotosError, check


class GoalStatus(enum.IntEnum):
    UNSPECIFIED = 0
    PENDING = 1
    ACCEPTED = 2
    EXECUTING = 3
    CANCELING = 4
    SUCCEEDED = 5
    CANCELED = 6
    ABORTED = 7
    REJECTED = 8


def _encode(msg) -> bytes:
    return bytes(msg) if isinstance(msg, (bytes, bytearray)) \
        else msg.SerializeToString()


def _decode(msg_type, data: bytes):
    if not isinstance(msg_type, type):
        return data                       # raw bytes pass-through
    m = msg_type()
    m.ParseFromString(data)
    return m


class GoalCtx:
    """Per-goal context — valid only inside the handler call."""

    def __init__(self, handle: int, feedback_type):
        self._ctx = handle
        self._feedback_type = feedback_type

    def cancel_requested(self) -> bool:
        return bool(_ffi.robotos_goal_cancel_requested(self._ctx))

    def send_feedback(self, feedback) -> None:
        data = _encode(feedback)
        buf = (ctypes.c_uint8 * max(len(data), 1)).from_buffer_copy(
            data or b"\x00")
        check(_ffi.robotos_goal_send_feedback(
            self._ctx, buf, len(data)), "send_feedback")


class ActionServer:
    """`handler(goal_msg, ctx) -> result_msg` on a daemon pump."""

    def __init__(self):
        self._handle = None
        self._trampoline = None
        self._thread = None
        self._queue = None

    @classmethod
    def create(
        cls, node, name: str,
        goal_type, feedback_type, result_type,
        handler: Callable[[Any, GoalCtx], Any],
    ) -> "ActionServer":
        srv = cls()
        q: queue.Queue = queue.Queue()
        srv._queue = q

        def _pump():
            while True:
                job = q.get()
                if job is None:
                    return
                goal_bytes, gctx, result, done = job
                try:
                    goal = _decode(goal_type, goal_bytes)
                    res = handler(goal, GoalCtx(gctx, feedback_type))
                    result["res"] = _encode(res)
                    result["status"] = 0
                except Exception as e:
                    result["status"] = getattr(e, "status", 255)
                    result["res"] = b""
                done.set()

        def _trampoline(goal_ptr, goal_len, gctx,
                        res_buf, res_cap, out_len, _u):
            data = ctypes.string_at(goal_ptr, goal_len)
            result: dict = {}
            done = threading.Event()
            q.put((data, gctx, result, done))
            done.wait()
            res = result.get("res", b"")
            if len(res) > res_cap:
                out_len[0] = 0
                return 6                    # PAYLOAD_TOO_LARGE
            if res:
                ctypes.memmove(res_buf, res, len(res))
            out_len[0] = len(res)
            return result.get("status", 255)

        srv._trampoline = _ffi.ACTION_HANDLER(_trampoline)
        srv._thread = threading.Thread(target=_pump, daemon=True)
        srv._thread.start()
        h = ctypes.c_void_p()
        try:
            check(
                _ffi.robotos_action_server_create(
                    node._handle, name.encode(),
                    srv._trampoline, None, ctypes.byref(h)),
                f"create_action {name}")
        except Exception:
            q.put(None)
            srv._thread.join(timeout=2.0)
            raise
        srv._handle = h.value
        return srv

    def close(self) -> None:
        if (self._thread is not None
                and threading.current_thread() is self._thread):
            threading.Thread(target=self.close, daemon=True).start()
            return
        if self._handle:
            _ffi.robotos_action_server_destroy(self._handle)
            self._handle = None
            try:
                self._queue.put_nowait(None)
            except Exception:
                pass
            if self._thread is not None:
                self._thread.join(timeout=2.0)
            self._trampoline = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


_GOAL_ID_CAP = 64


class ActionClient:
    """`send_goal` → `feedback`/`result`/`cancel` per goal id."""

    def __init__(self, handle, result_type, feedback_type):
        self._handle = handle
        self._result_type = result_type
        self._feedback_type = feedback_type
        self._fb_thread = None
        self._fb_stop = threading.Event()

    @classmethod
    def create(cls, node, name: str,
               goal_type, feedback_type, result_type) -> "ActionClient":
        h = ctypes.c_void_p()
        check(
            _ffi.robotos_action_client_create(
                node._handle, name.encode(), ctypes.byref(h)),
            f"action_client {name}")
        return cls(h.value, result_type, feedback_type)

    def send_goal(self, goal, timeout_ms: int = 5000) -> str:
        data = _encode(goal)
        buf = (ctypes.c_uint8 * max(len(data), 1)).from_buffer_copy(
            data or b"\x00")
        id_buf = ctypes.create_string_buffer(_GOAL_ID_CAP)
        out_len = ctypes.c_size_t(0)
        check(_ffi.robotos_action_send_goal(
            self._handle, buf, len(data), timeout_ms,
            id_buf, _GOAL_ID_CAP, ctypes.byref(out_len)),
            "send_goal")
        return id_buf.value.decode()

    def cancel(self, goal_id: str, timeout_ms: int = 5000) -> GoalStatus:
        state = ctypes.c_uint32(0)
        check(_ffi.robotos_action_cancel(
            self._handle, goal_id.encode(), timeout_ms,
            ctypes.byref(state)), "action_cancel")
        return GoalStatus(state.value)

    def result(
        self, goal_id: str, timeout_ms: int = 5000,
    ) -> tuple[GoalStatus, Any]:
        state = ctypes.c_uint32(0)
        msg = _ffi.Message()
        check(_ffi.robotos_action_result(
            self._handle, goal_id.encode(), timeout_ms,
            ctypes.byref(state), ctypes.byref(msg)), "action_result")
        try:
            payload = ctypes.string_at(msg.data, msg.len)
        finally:
            _ffi.robotos_message_free(ctypes.byref(msg))
        return GoalStatus(state.value), _decode(self._result_type, payload)

    def feedback_recv(
        self, goal_id: str, timeout_ms: int = 5000,
    ) -> Optional[Any]:
        """Next feedback for this goal; None on timeout."""
        msg = _ffi.Message()
        st = _ffi.robotos_action_feedback_recv(
            self._handle, goal_id.encode(), timeout_ms,
            ctypes.byref(msg))
        if st == 8:                          # TIMEOUT
            return None
        check(st, "feedback_recv")
        try:
            payload = ctypes.string_at(msg.data, msg.len)
        finally:
            _ffi.robotos_message_free(ctypes.byref(msg))
        return _decode(self._feedback_type, payload)

    def on_feedback(
        self, goal_id: str, cb: Callable[[Any], None],
    ) -> None:
        """Daemon pump — calls `cb(feedback_msg)` until the goal
        terminates or the client closes."""
        def _pump():
            while not self._fb_stop.is_set():
                fb = self.feedback_recv(goal_id, 500)
                if fb is not None:
                    cb(fb)
        self._fb_thread = threading.Thread(target=_pump, daemon=True)
        self._fb_thread.start()

    def close(self) -> None:
        self._fb_stop.set()
        # Join the pump BEFORE destroying the handle — an in-flight
        # feedback_recv may still hold the raw handle.
        t = getattr(self, "_fb_thread", None)
        if (t is not None and t.is_alive()
                and threading.current_thread() is not t):
            t.join(timeout=2.0)
        if self._handle:
            _ffi.robotos_action_client_destroy(self._handle)
            self._handle = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
