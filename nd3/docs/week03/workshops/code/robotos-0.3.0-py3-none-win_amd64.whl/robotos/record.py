"""Record/replay — `.rbag` bags (BAG-01).

`recorder()` subscribes to the listed topics and writes envelopes to
disk; `stop()` finalizes (destroy is a fallback). `replay()` reads a
bag back onto the mesh; `bag_info()` returns the JSON metadata.
"""

from __future__ import annotations

import ctypes
import json
from typing import Optional

from . import _ffi
from .errors import check


class Recorder:
    """Topic recorder — `close()`/`stop()` finalizes the bag."""

    def __init__(self):
        self._handle = None

    @classmethod
    def create(
        cls, node, topics: list[str], path: str, label: str = "",
    ) -> "Recorder":
        rec = cls()
        h = ctypes.c_void_p()
        check(_ffi.robotos_recorder_create(
            node._handle, ",".join(topics).encode(),
            path.encode(), label.encode(), ctypes.byref(h)),
            "recorder_create")
        rec._handle = h.value
        return rec

    @property
    def count(self) -> int:
        return _ffi.robotos_recorder_count(self._handle)

    def stop(self) -> None:
        """Finalize the bag file; the handle stays closable."""
        if self._handle:
            check(_ffi.robotos_recorder_stop(self._handle), "recorder_stop")

    def close(self) -> None:
        if self._handle:
            _ffi.robotos_recorder_destroy(self._handle)
            self._handle = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class ReplayReport(ctypes.Structure):
    _fields_ = _ffi.ReplayReport._fields_

    def as_dict(self) -> dict:
        return {f[0]: getattr(self, f[0]) for f in self._fields_}


def replay(
    node, path: str, rate: float = 1.0, allow_command_topics: bool = False,
    topics: Optional[list[str]] = None, prefix: Optional[str] = None,
) -> dict:
    """Replay `path` onto this node's mesh — returns the report dict."""
    report = _ffi.ReplayReport()
    check(_ffi.robotos_replay(
        node._handle, path.encode(), rate,
        1 if allow_command_topics else 0,
        ",".join(topics).encode() if topics else None,
        prefix.encode() if prefix else None,
        ctypes.byref(report)), "replay")
    return ReplayReport.from_address(
        ctypes.addressof(report)).as_dict()


def bag_info(path: str) -> dict:
    """Bag metadata as a dict (parsed from the ABI's JSON blob)."""
    buf = ctypes.create_string_buffer(8192)
    out_len = ctypes.c_size_t(0)
    check(_ffi.robotos_bag_info(
        path.encode(), buf, len(buf), ctypes.byref(out_len)), "bag_info")
    return json.loads(buf.value.decode())
