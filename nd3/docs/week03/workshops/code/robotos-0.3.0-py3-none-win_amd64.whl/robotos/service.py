"""Services — unary RPC (ADR 0008/0009).

Unlike message callbacks, the service handler must produce its reply
INSIDE the ABI call. We still keep user code off the ABI worker:
the trampoline posts the request to a daemon pump thread and blocks
on an Event until the pump returns the reply — user handlers may
call robotos APIs because they never run on the ABI thread.
"""

from __future__ import annotations

import ctypes
import queue
import threading
from typing import Any, Callable

from . import _ffi
from .errors import check

MAX_RPC_PAYLOAD = 4 * 1024 * 1024


class Service:
    """Declared unary service. `handler(req_msg) -> resp_msg` runs on
    a daemon pump thread; raise `RobotosError` to return a status."""

    def __init__(self):
        self._handle = None
        self._trampoline = None
        self._thread = None
        self._queue = None

    @classmethod
    def create(
        cls, node, name: str, req_type: Any, resp_type: Any,
        handler: Callable[[Any], Any],
    ) -> "Service":
        from .node import _schema_id

        svc = cls()
        q: queue.Queue = queue.Queue()
        svc._queue = q

        def _pump():
            while True:
                job = q.get()
                if job is None:
                    return
                data, result, done = job
                try:
                    req = req_type() if isinstance(req_type, type) else data
                    if isinstance(req_type, type):
                        req.ParseFromString(data)
                    resp = handler(req)
                    result["resp"] = (
                        resp if isinstance(resp, (bytes, bytearray))
                        else resp.SerializeToString())
                    result["status"] = 0
                except Exception as e:
                    result["status"] = getattr(e, "status", 255)
                    result["resp"] = b""
                done.set()

        def _trampoline(req_ptr, req_len, resp_buf, resp_cap, out_len, _u):
            data = ctypes.string_at(req_ptr, req_len)
            result: dict = {}
            done = threading.Event()
            q.put((data, result, done))
            if not done.wait(timeout=30.0):
                # pump died — unwedge the ABI worker instead of
                # blocking it forever
                out_len[0] = 0
                return 255
            resp = result.get("resp", b"")
            if len(resp) > resp_cap:
                out_len[0] = 0
                return 6                       # PAYLOAD_TOO_LARGE
            if resp:
                ctypes.memmove(resp_buf, resp, len(resp))
            out_len[0] = len(resp)
            return result.get("status", 255)

        svc._trampoline = _ffi.SERVICE_HANDLER(_trampoline)
        svc._thread = threading.Thread(target=_pump, daemon=True)
        svc._thread.start()
        h = ctypes.c_void_p()
        try:
            check(
                _ffi.robotos_service_create(
                    node._handle, name.encode(),
                    _schema_id(req_type).encode(),
                    _schema_id(resp_type).encode(),
                    svc._trampoline, None, ctypes.byref(h)),
                "create_service")
        except Exception:
            q.put(None)
            svc._thread.join(timeout=2.0)
            raise
        svc._handle = h.value
        return svc

    def close(self) -> None:
        if (self._thread is not None
                and threading.current_thread() is self._thread):
            # close() inside its own handler would join the pump
            # thread from itself and deadlock the ABI worker waiting
            # on `done` — defer teardown to a helper thread.
            threading.Thread(target=self.close, daemon=True).start()
            return
        if self._handle:
            # joins in-flight handler calls before touching user_data
            _ffi.robotos_service_destroy(self._handle)
            self._handle = None
            try:
                self._queue.put_nowait(None)
            except Exception:
                pass
            if self._thread is not None:
                self._thread.join(timeout=2.0)
            self._trampoline = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def client_call(
    node, name: str, req_type: Any, resp_type: Any, req: Any,
    timeout_ms: int = 5000,
) -> Any:
    """Unary call — returns the decoded reply. Raises RobotosError
    (UNAVAILABLE until the service queryable propagates — callers
    should retry with backoff)."""
    from .node import _schema_id

    data = (req if isinstance(req, (bytes, bytearray))
            else req.SerializeToString())
    buf = (ctypes.c_uint8 * max(len(data), 1)).from_buffer_copy(
        data or b"\x00")
    msg = _ffi.Message()
    st = _ffi.robotos_client_call(
        node._handle, name.encode(),
        _schema_id(req_type).encode(), _schema_id(resp_type).encode(),
        buf, len(data), timeout_ms, ctypes.byref(msg))
    check(st, f"call {name}")
    try:
        payload = ctypes.string_at(msg.data, msg.len)
    finally:
        _ffi.robotos_message_free(ctypes.byref(msg))
    if not isinstance(resp_type, type):
        return payload
    resp = resp_type()
    resp.ParseFromString(payload)
    return resp
