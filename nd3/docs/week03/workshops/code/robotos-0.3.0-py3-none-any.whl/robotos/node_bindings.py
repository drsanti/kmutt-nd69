"""Explicit endpoint contracts over the C ABI; payloads remain unchanged."""
import ctypes as c
from contextlib import contextmanager
from . import _ffi
from .coordinates import Frame
from .node_axes import encoded
from .errors import check

class Binding(c.Structure):
    _fields_ = [("struct_size", c.c_uint32), ("quantity", c.c_char_p), ("frame", c.c_void_p)]

@contextmanager
def native_bindings(bindings):
    if not hasattr(bindings, "items") or not 1 <= len(bindings) <= 8: raise ValueError("expected 1..8 quantity-to-Frame bindings")
    create = _ffi._sig("robotos_frame_create", c.c_uint32, [c.c_uint32,c.c_char_p,c.c_char_p,c.c_char_p,c.c_int32,c.c_int32,c.POINTER(c.c_void_p)])
    destroy = _ffi._sig("robotos_frame_destroy", None, [c.c_void_p])
    handles, rows = [], []
    codes={"+X":1,"-X":-1,"+Y":2,"-Y":-2,"+Z":3,"-Z":-3,None:0}
    try:
        for quantity, frame in bindings.items():
            if not isinstance(frame,Frame): raise TypeError("binding must be a Frame")
            handle=c.c_void_p()
            check(create(frame.domain,encoded(frame.namespace),encoded(frame.authority),encoded(frame.frame_id),codes[frame.convention.up_axis],codes[frame.convention.forward_axis],c.byref(handle)),"binding frame")
            handles.append(handle)
            rows.append(Binding(c.sizeof(Binding),encoded(quantity),handle))
        yield (Binding * len(rows))(*rows)
    finally:
        for handle in handles: destroy(handle)

def create_endpoint(node, topic, schema, bindings, timeout_ms=None):
    args=[c.c_void_p,c.c_char_p,c.c_char_p,c.POINTER(Binding),c.c_size_t]
    values=[node._handle,encoded(topic),encoded(schema)]
    name="robotos_publisher_create_with_frames"
    if timeout_ms is not None:
        if type(timeout_ms) is not int or not 1<=timeout_ms<=60000: raise ValueError("timeout must be 1..60000 ms")
        name="robotos_subscriber_create_with_frames"
        args.append(c.c_uint32)
    args.append(c.POINTER(c.c_void_p))
    function=_ffi._sig(name,c.c_uint32,args)
    with native_bindings(bindings) as native:
        values.extend([native,len(native)])
        if timeout_ms is not None: values.append(timeout_ms)
        out=c.c_void_p()
        check(function(*values,c.byref(out)),name)
        return out.value
