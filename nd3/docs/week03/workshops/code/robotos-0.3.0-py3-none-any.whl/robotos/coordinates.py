"""Immutable local frames (ADR 0029); no TF discovery or motion side effects."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import math

_AXES = {"+X": (1., 0., 0.), "-X": (-1., 0., 0.), "+Y": (0., 1., 0.),
         "-Y": (0., -1., 0.), "+Z": (0., 0., 1.), "-Z": (0., 0., -1.)}
_PRESETS = {"z_up_x_forward": ("+Z", "+X"), "y_up_x_forward": ("+Y", "+X"),
            "y_up_neg_z_forward": ("+Y", "-Z")}

class UndefinedDirection(ValueError):
    """The frame has no declared semantic heading."""

class UnsupportedTransform(ValueError):
    """An explicit time-valid transform is required; lookup is not implemented."""

@dataclass(frozen=True, slots=True)
class Convention:
    up_axis: str
    forward_axis: str | None = None

    def __post_init__(self):
        if self.up_axis not in _AXES or (self.forward_axis is not None and self.forward_axis not in _AXES):
            raise ValueError("axis must be +X, -X, +Y, -Y, +Z or -Z")
        if self.forward_axis and self.up_axis[1] == self.forward_axis[1]:
            raise ValueError("forward and up must use perpendicular axes")

    @classmethod
    def preset(cls, name: str) -> Convention:
        if name not in _PRESETS:
            raise ValueError("unknown coordinate preset")
        return cls(*_PRESETS[name])

    @property
    def definition_hash(self) -> str:
        definition = f"robotos.axes.v1|right|m|rad|up={self.up_axis}|forward={self.forward_axis or 'none'}"
        return hashlib.sha256(definition.encode("ascii")).hexdigest()

    handedness = property(lambda self: "right")
    length_unit = property(lambda self: "m")
    angle_unit = property(lambda self: "rad")
    version = property(lambda self: 1)

@dataclass(frozen=True, slots=True)
class Frame:
    domain: int
    namespace: str
    authority: str
    frame_id: str
    convention: Convention

    def __post_init__(self):
        if type(self.domain) is not int or not 0 <= self.domain <= 0xffffffff:
            raise ValueError("domain must be a u32")
        if any(not isinstance(s, str) or not s or "\0" in s for s in (self.namespace, self.authority, self.frame_id)):
            raise ValueError("frame namespace, authority and ID must be nonempty and contain no NUL")
        if not isinstance(self.convention, Convention):
            raise TypeError("convention must be a Convention")

    @property
    def directions(self) -> Directions:
        return Directions(self)

    dirs = property(lambda self: self.directions)
    axes = property(lambda self: Axes(self))

@dataclass(frozen=True, slots=True)
class FrameVector:
    frame: Frame
    components: tuple[float, float, float]

    def __post_init__(self):
        values = tuple(self.components)
        if not isinstance(self.frame, Frame) or len(values) != 3 or not all(math.isfinite(v) for v in values):
            raise ValueError("expected a frame and three finite components")
        object.__setattr__(self, "components", tuple(0.0 if v == 0 else v for v in values))

    def expressed_in(self, target: Frame) -> FrameVector:
        if target != self.frame:
            raise UnsupportedTransform("cross-frame expression requires an explicit time-valid transform")
        return self

@dataclass(frozen=True, slots=True)
class Directions:
    frame: Frame

    def _get(self, name: str) -> FrameVector:
        up = _AXES[self.frame.convention.up_axis]
        if name in ("UP", "DOWN"):
            vector = up
        else:
            forward_axis = self.frame.convention.forward_axis
            if forward_axis is None:
                raise UndefinedDirection("direction is undefined: this convention has no forward heading")
            forward = _AXES[forward_axis]
            vector = forward if name in ("FORWARD", "BACKWARD") else (
                up[1]*forward[2]-up[2]*forward[1], up[2]*forward[0]-up[0]*forward[2], up[0]*forward[1]-up[1]*forward[0])
        if name in ("BACKWARD", "RIGHT", "DOWN"):
            vector = tuple(-v for v in vector)
        return FrameVector(self.frame, vector)

    FORWARD = property(lambda self: self._get("FORWARD"))
    BACKWARD = property(lambda self: self._get("BACKWARD"))
    LEFT = property(lambda self: self._get("LEFT"))
    RIGHT = property(lambda self: self._get("RIGHT"))
    UP = property(lambda self: self._get("UP"))
    DOWN = property(lambda self: self._get("DOWN"))
    F, B, L, R, U, D = FORWARD, BACKWARD, LEFT, RIGHT, UP, DOWN

@dataclass(frozen=True, slots=True)
class Axes:
    frame: Frame
    X = property(lambda self: FrameVector(self.frame, (1., 0., 0.)))
    Y = property(lambda self: FrameVector(self.frame, (0., 1., 0.)))
    Z = property(lambda self: FrameVector(self.frame, (0., 0., 1.)))


def _transpose(a):
    return tuple(zip(*a))

def _multiply(a, b):
    return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)) for i in range(3))

def _finite(values, size):
    values = tuple(values)
    if len(values) != size or not all(math.isfinite(v) for v in values):
        raise ValueError("expected finite numeric components")
    return values

def _normalize(q):
    q = _finite(q, 4)
    scale = max(map(abs, q))
    if scale == 0: raise ValueError("zero quaternion")
    q = tuple(v/scale for v in q)
    norm = math.sqrt(sum(v*v for v in q))
    return tuple(v/norm * (-1 if q[3] < 0 else 1) for v in q)

@dataclass(frozen=True, slots=True, init=False)
class BasisChange:
    """Same-origin basis conversion. Does not resolve physical frame transforms."""
    matrix: tuple

    def __init__(self, source: Convention, target: Convention):
        def basis(c):
            if c.forward_axis is None: raise UndefinedDirection("basis conversion requires a heading")
            f, u = _AXES[c.forward_axis], _AXES[c.up_axis]
            l = (u[1]*f[2]-u[2]*f[1], u[2]*f[0]-u[0]*f[2], u[0]*f[1]-u[1]*f[0])
            return _transpose((f, l, u))
        object.__setattr__(self, "matrix", _multiply(basis(target), _transpose(basis(source))))

    def vector(self, value):
        value = _finite(value, 3)
        return _finite((sum(row[j]*value[j] for j in range(3)) for row in self.matrix), 3)

    def quaternion(self, child: BasisChange, value):
        """Re-express child-to-parent rotation as C_parent R C_child^-1; xyzw."""
        x, y, z, w = _normalize(value)
        r = ((1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)),
             (2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)),
             (2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)))
        r = _multiply(_multiply(self.matrix, r), _transpose(child.matrix))
        trace = sum(r[i][i] for i in range(3))
        if trace > 0:
            s = math.sqrt(trace+1)*2
            q = ((r[2][1]-r[1][2])/s, (r[0][2]-r[2][0])/s, (r[1][0]-r[0][1])/s, s/4)
        else:
            i = max(range(3), key=lambda i: r[i][i])
            j, k = (i+1)%3, (i+2)%3
            s = math.sqrt(max(0, 1+r[i][i]-r[j][j]-r[k][k]))*2
            q = [0.]*4
            q[i], q[j], q[k], q[3] = s/4, (r[i][j]+r[j][i])/s, (r[i][k]+r[k][i])/s, (r[k][j]-r[j][k])/s
        return _normalize(q)

    def vector_covariance(self, value):
        """3x3 covariance of vector components, not pose/Euler-angle covariance."""
        value = tuple(_finite(row, 3) for row in value)
        if len(value) != 3: raise ValueError("expected 3x3 covariance")
        result = _multiply(_multiply(self.matrix, value), _transpose(self.matrix))
        return tuple(_finite(row, 3) for row in result)
