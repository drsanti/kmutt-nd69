"""Node-owned coordinate declarations; all remote operations are read-only."""
import ctypes
import json
import weakref
from functools import lru_cache
from . import _ffi
from .coordinates import Convention, Frame
from .errors import check

@lru_cache(None)
def function(name):
    u32, ptr, text, size = ctypes.c_uint32, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t
    signatures = {
        "robotos_node_axes_json": (u32, [ptr,text,text,u32,ptr,size,ctypes.POINTER(size)]),
        "robotos_node_declare_frame": (u32, [ptr,text,ctypes.c_int32,ctypes.c_int32,ctypes.POINTER(ptr)]),
        "robotos_frame_destroy": (None,[ptr]),
        "robotos_node_create_from_file": (u32,[text,text,ctypes.POINTER(ptr)]),
        "robotos_node_create_with_coordinates": (u32,[text,text,text,ctypes.c_uint16,ctypes.c_int,text,ctypes.POINTER(ptr)]),
    }
    result,args=signatures[name]
    try: return _ffi._sig(name,result,args)
    except AttributeError as e: raise RuntimeError("coordinate discovery requires the rebuilt native library") from e

def encoded(value):
    if not isinstance(value,str) or not value or "\0" in value: raise ValueError("expected nonempty string without NUL")
    return value.encode("utf-8")

def from_descriptor(d):
    c=d["convention"]
    if c["version"]!=1 or c["handedness"]!="right" or c["length_unit"]!="m" or c["angle_unit"]!="rad": raise ValueError("unsupported convention metadata")
    convention=Convention(c["up_axis"],c["forward_axis"])
    if convention.definition_hash!=c["definition_hash"]: raise ValueError("invalid convention hash")
    return Frame(d["domain"],d["namespace"],d["authority"],d["frame_id"],convention)

class NodeAxes:
    def __init__(self,node): self._node=weakref.proxy(node)
    def snapshot(self, owner_uuid=None, frame_id=None, timeout_ms=3000):
        with self._node._coordinate_operation():
            return self._snapshot(owner_uuid,frame_id,timeout_ms)
    def _snapshot(self, owner_uuid=None, frame_id=None, timeout_ms=3000):
        if type(timeout_ms) is not int or not 1<=timeout_ms<=60000: raise ValueError("timeout must be 1..60000 ms")
        owner=encoded(owner_uuid) if owner_uuid is not None else None
        frame=encoded(frame_id) if frame_id is not None else None
        capacity=4096
        for _ in range(4):
            buffer=ctypes.create_string_buffer(capacity)
            length=ctypes.c_size_t()
            status=function("robotos_node_axes_json")(self._node._handle,owner,frame,timeout_ms,buffer,capacity,ctypes.byref(length))
            if status==14 and length.value>=capacity:
                if length.value>4*1024*1024: raise ValueError("axes snapshot exceeds limit")
                capacity=length.value+1
                continue
            check(status,"axes snapshot")
            return json.loads(buffer.raw[:length.value])
        raise RuntimeError("axes snapshot kept growing; retry query")
    def list_frames(self, owner_uuid=None, timeout_ms=3000):
        return [from_descriptor(d) for d in self.snapshot(owner_uuid,timeout_ms=timeout_ms)["frames"]]
    def get_frame(self, frame_id, owner_uuid=None, timeout_ms=3000):
        return from_descriptor(self.snapshot(owner_uuid,frame_id,timeout_ms)["frames"][0])
    def default_convention(self, owner_uuid=None, timeout_ms=3000):
        c=self.snapshot(owner_uuid,timeout_ms=timeout_ms)["default_convention"]
        return Convention(c["up_axis"],c["forward_axis"])
    def declare_frame(self, frame_id, convention=None):
        with self._node._coordinate_operation():
            axes={"+X":1,"-X":-1,"+Y":2,"-Y":-2,"+Z":3,"-Z":-3,None:0}
            if convention is not None and not isinstance(convention,Convention): raise TypeError("expected Convention")
            out=ctypes.c_void_p()
            check(function("robotos_node_declare_frame")(self._node._handle,encoded(frame_id),axes[convention.up_axis] if convention else 0,axes[convention.forward_axis] if convention else 0,ctypes.byref(out)),"declare frame")
            function("robotos_frame_destroy")(out)
            return from_descriptor(self._snapshot(frame_id=frame_id)["frames"][0])
