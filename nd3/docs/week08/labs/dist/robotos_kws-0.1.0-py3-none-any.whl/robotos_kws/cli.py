"""Unified Command-Line Interface (CLI) for robotos_kws."""
from __future__ import annotations

import argparse
import sys
from typing import List, Optional

import collect
import collect_imu
import collect_pc_mic
import evaluate
import export_c_array
import live_infer_board
import live_infer_imu
import live_infer_pc
import make_synthetic_dataset
import train
import train_imu
import verify_c_features
from robotos_kws.audio import print_devices


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="robotos-kws",
        description="robotos_kws: Edge AI Keyword Spotting Toolkit for ESP32-S3 and PC",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Quick Examples:
  # Audio KWS (Computer Mic / ES3C28P Board)
  robotos-kws devices
  robotos-kws check-board --port COM5 --gain 80
  robotos-kws collect-pc --speaker me --session s01 --labels blue --takes 20
  robotos-kws collect-board --port COM5 --gain 80 --takes 20
  robotos-kws train --data dataset --out artifacts --epochs 40 --augment 4
  robotos-kws evaluate --artifacts artifacts --data dataset
  robotos-kws live-pc --model artifacts/model_int8.tflite
  robotos-kws live-board --port COM5 --gain 80 --model artifacts/model_int8.tflite
  robotos-kws export --model artifacts/model_int8.tflite --out-dir ../firmware/kws-inference/main

  # IMU Gestures (ws28p Board)
  robotos-kws check-imu --port COM7
  robotos-kws collect-imu --port COM7 --person alice --session s01 --takes 20
  robotos-kws train-imu --data imu_dataset --out imu_artifacts --epochs 60
  robotos-kws live-imu --port COM7 --model imu_artifacts/model_int8.tflite
        """,
    )
    subparsers = parser.add_subparsers(dest="command", title="Available Subcommands", required=True)

    # 1. devices
    subparsers.add_parser("devices", help="List audio input devices on this computer")

    # 2. check-board
    p_check = subparsers.add_parser("check-board", help="Check ESP32-S3 board connection and live mic dBFS meter")
    p_check.add_argument("--port", required=True, help="Serial port, e.g. COM5 or /dev/ttyACM0")
    p_check.add_argument("--gain", type=int, default=80, help="Mic gain 0-100%% (default 80)")

    # 3. collect-pc
    subparsers.add_parser("collect-pc", help="Record keyword clips with computer microphone (Path B)", add_help=False)

    # 4. collect-board
    subparsers.add_parser("collect-board", help="Record keyword clips streamed from board mic (Path C)", add_help=False)

    # 5. synth-data
    subparsers.add_parser("synth-data", aliases=["synth"], help="Generate synthetic audio dataset for testing", add_help=False)

    # 6. train
    subparsers.add_parser("train", help="Train DS-CNN model and export float32 + int8 TFLite", add_help=False)

    # 7. evaluate
    subparsers.add_parser("evaluate", help="Benchmark accuracy, confusion matrix, and generate report.md", add_help=False)

    # 8. live-pc
    subparsers.add_parser("live-pc", help="Run real-time keyword spotting through PC mic or audio file", add_help=False)

    # 9. live-board
    subparsers.add_parser("live-board", help="Run real-time keyword spotting streamed from board over USB", add_help=False)

    # 10. export
    subparsers.add_parser("export", help="Export model as C array and header for ESP-IDF firmware", add_help=False)

    # 11. verify-c
    subparsers.add_parser("verify-c", help="Cross-check C feature extraction against Python log-mel", add_help=False)

    # 12. check-imu
    p_check_imu = subparsers.add_parser("check-imu", help="Check ws28p board connection and live 50 Hz IMU telemetry")
    p_check_imu.add_argument("--port", required=True, help="Serial port, e.g. COM7 or /dev/ttyACM0")

    # 13. collect-imu
    subparsers.add_parser("collect-imu", help="Collect motion gesture windows from ws28p board over USB", add_help=False)

    # 14. train-imu
    subparsers.add_parser("train-imu", help="Train 1D-CNN motion gesture classifier and export int8 model", add_help=False)

    # 15. live-imu
    subparsers.add_parser("live-imu", help="Run real-time sliding-window motion recognition from board stream or CSV replay", add_help=False)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = create_parser()
    if not argv:
        parser.print_help()
        return 0

    cmd = argv[0]
    sub_args = argv[1:]

    if cmd in ("-h", "--help"):
        parser.print_help()
        return 0

    if cmd == "devices":
        print_devices()
        return 0
    elif cmd == "check-board":
        p = argparse.ArgumentParser(prog="robotos-kws check-board")
        p.add_argument("--port", required=True)
        p.add_argument("--gain", type=int, default=80)
        parsed = p.parse_args(sub_args)
        return collect.main(["--port", parsed.port, "--gain", str(parsed.gain), "--info"])
    elif cmd == "collect-pc":
        return collect_pc_mic.main(sub_args)
    elif cmd == "collect-board":
        return collect.main(sub_args)
    elif cmd in ("synth-data", "synth"):
        return make_synthetic_dataset.main(sub_args)
    elif cmd == "train":
        return train.main(sub_args)
    elif cmd == "evaluate":
        return evaluate.main(sub_args)
    elif cmd == "live-pc":
        return live_infer_pc.main(sub_args)
    elif cmd == "live-board":
        return live_infer_board.main(sub_args)
    elif cmd == "export":
        return export_c_array.main(sub_args)
    elif cmd == "verify-c":
        return verify_c_features.main(sub_args)
    elif cmd == "check-imu":
        p = argparse.ArgumentParser(prog="robotos-kws check-imu")
        p.add_argument("--port", required=True)
        parsed = p.parse_args(sub_args)
        return collect_imu.main(["--port", parsed.port, "--check"])
    elif cmd == "collect-imu":
        return collect_imu.main(sub_args)
    elif cmd == "train-imu":
        return train_imu.main(sub_args)
    elif cmd == "live-imu":
        return live_infer_imu.main(sub_args)
    else:
        print(f"Unknown command: {cmd}")
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
