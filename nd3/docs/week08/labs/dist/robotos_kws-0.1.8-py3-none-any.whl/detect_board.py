#!/usr/bin/env python3
"""Hardware auto-detection and wire protocol handshake for RobotOS ESP32-S3 boards.

Scans host serial ports, identifies ESP32-S3 microcontrollers (ws28p / es3c28p),
probes the wire protocol handshake (COBS + CRC-16 + Protobuf BoardInfo / IMU / Audio),
and displays live board telemetry and recommended commands.

Usage:
    robotos detect
    robotos-detect
    robotos-kws detect
    python detect_board.py [--json] [--timeout 2.0]
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict, dataclass
from typing import List, Optional

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None

import wire


@dataclass
class BoardInfoResult:
    port: str
    description: str
    vid: Optional[int]
    pid: Optional[int]
    status: str            # "ready", "unflashed", "busy", "error"
    model: str             # "ws28p", "es3c28p", "esp32s3", "unknown"
    caps: int
    caps_str: str
    uuid: str
    fw_version: str
    sensor_preview: str
    suggested_command: str
    troubleshooting: str = ""


def _scan_serial_ports():
    """Return all serial port device info objects."""
    if serial is None or not hasattr(serial.tools, "list_ports"):
        return []
    return list(serial.tools.list_ports.comports())


def probe_single_port(port_info, timeout_s: float = 2.0) -> BoardInfoResult:
    """Probe a single serial port for ESP32-S3 wire protocol and BoardInfo."""
    device = port_info.device
    desc = port_info.description or "Unknown Serial Device"
    hwid = port_info.hwid or ""
    vid = port_info.vid
    pid = port_info.pid

    # Normalize macOS callout device
    if sys.platform == "darwin" and device.startswith("/dev/tty."):
        device = device.replace("/dev/tty.", "/dev/cu.")

    # 1. Try to open the port with non-resetting DTR/RTS states
    try:
        sess = wire.BoardSession.open(device, settle_s=0.6)
    except wire.WireError as e:
        err_msg = str(e).lower()
        if "access is denied" in err_msg or "busy" in err_msg or "permission" in err_msg:
            return BoardInfoResult(
                port=device,
                description=desc,
                vid=vid,
                pid=pid,
                status="busy",
                model="esp32s3",
                caps=0,
                caps_str="unknown",
                uuid="",
                fw_version="",
                sensor_preview="Port is in use by another application",
                suggested_command="",
                troubleshooting="Close Arduino IDE, VSCode Serial Monitor, or Chrome WebSerial tabs.",
            )
        return BoardInfoResult(
            port=device,
            description=desc,
            vid=vid,
            pid=pid,
            status="error",
            model="unknown",
            caps=0,
            caps_str="none",
            uuid="",
            fw_version="",
            sensor_preview=str(e),
            suggested_command="",
            troubleshooting="Unplug and replug the USB-C cable.",
        )

    # 2. Listen for live wire protocol frames
    t0 = time.monotonic()
    seen_imu = []
    seen_audio = []
    info: Optional[wire.BoardInfo] = None

    try:
        # First check if board already buffered or is actively streaming
        while time.monotonic() - t0 < timeout_s:
            for f in sess.poll(0.05):
                if f.msg_type == wire.MSG_BOARD_INFO:
                    try:
                        info = wire.decode_board_info(f.payload)
                    except ValueError:
                        pass
                elif f.msg_type == wire.MSG_IMU:
                    try:
                        imu = wire.decode_imu(f.payload)
                        seen_imu.append(imu)
                    except Exception:
                        pass
                elif f.msg_type == wire.MSG_AUDIO_LEVEL:
                    try:
                        seen_audio.append(wire.decode_audio_level(f.payload))
                    except Exception:
                        pass

            # If we received both BoardInfo and a sensor frame, or >= 10 IMU frames, we can finish early
            if (info and (seen_imu or seen_audio)) or len(seen_imu) >= 15:
                break

            # If 0.8s passed without any frame, try probing mic with harmless MicCmd query
            if time.monotonic() - t0 > 0.8 and not seen_imu and not seen_audio and not info:
                try:
                    # Harmless command: query mic without turning stream on
                    sess.write_frame(wire.MSG_MIC_CMD, wire.encode_mic_cmd(gain_pct=80, stream=False))
                except Exception:
                    pass

    finally:
        sess.close()

    # 3. Analyze probe findings
    if seen_imu:
        # ws28p motion board
        model = info.hw_model if (info and info.hw_model) else "ws28p"
        uuid = info.uuid if info else ""
        fw_ver = info.fw_version if info else "robotos-fw"
        caps = info.caps if (info and info.caps) else wire.BOARD_CAPS.get("ws28p", 0x3C)

        # Calculate live gravity magnitude from recent samples
        mean_accel = [
            sum(s.accel[i] for s in seen_imu) / len(seen_imu)
            for i in range(3)
        ]
        mag = sum(x ** 2 for x in mean_accel) ** 0.5
        rate = len(seen_imu) / max(0.1, time.monotonic() - t0)

        preview = f"50 Hz IMU streaming ({len(seen_imu)} frames, ~{rate:.0f} Hz) |a| = {mag:.2f} m/s² [gravity verified]"
        cmd = f"robotos check-imu --port {device}"

        return BoardInfoResult(
            port=device,
            description=desc,
            vid=vid,
            pid=pid,
            status="ready",
            model=model,
            caps=caps,
            caps_str=wire.caps_str(caps),
            uuid=uuid,
            fw_version=fw_ver,
            sensor_preview=preview,
            suggested_command=cmd,
        )

    if seen_audio or (info and info.has(wire.CAP_MIC)):
        # es3c28p audio board
        model = info.hw_model if (info and info.hw_model) else "es3c28p"
        uuid = info.uuid if info else ""
        fw_ver = info.fw_version if info else "robotos-fw"
        caps = info.caps if (info and info.caps) else wire.BOARD_CAPS.get("es3c28p", 0x33)

        dbfs = f"{seen_audio[-1].dbfs:.1f} dBFS" if seen_audio else "idle"
        preview = f"Microphone active (ES8311 codec verified, noise: {dbfs})"
        cmd = f"robotos check-board --port {device} --gain 80"

        return BoardInfoResult(
            port=device,
            description=desc,
            vid=vid,
            pid=pid,
            status="ready",
            model=model,
            caps=caps,
            caps_str=wire.caps_str(caps),
            uuid=uuid,
            fw_version=fw_ver,
            sensor_preview=preview,
            suggested_command=cmd,
        )

    if info:
        # Other workshop board
        model = info.hw_model or "esp32s3"
        return BoardInfoResult(
            port=device,
            description=desc,
            vid=vid,
            pid=pid,
            status="ready",
            model=model,
            caps=info.caps,
            caps_str=wire.caps_str(info.caps),
            uuid=info.uuid,
            fw_version=info.fw_version,
            sensor_preview="Connected (BoardInfo received)",
            suggested_command=f"robotos-kws --port {device}",
        )

    # Port opened successfully, but zero wire frames received
    # Board is likely unprogrammed or running non-workshop firmware (e.g. factory demo)
    return BoardInfoResult(
        port=device,
        description=desc,
        vid=vid,
        pid=pid,
        status="unflashed",
        model="esp32s3",
        caps=0,
        caps_str="none",
        uuid="",
        fw_version="",
        sensor_preview="No workshop BoardInfo handshake received (board needs flashing)",
        suggested_command=f"robotos flash-firmware --port {device} --board ws28p",
        troubleshooting="Flash workshop firmware with 'robotos flash-firmware' to enable telemetry streaming.",
    )


def detect_boards(timeout_s: float = 2.0) -> List[BoardInfoResult]:
    """Scan all serial ports and return diagnostic results for all ESP32-S3 boards."""
    all_ports = _scan_serial_ports()
    esp_ports = []

    for p in all_ports:
        desc = p.description or ""
        hwid = p.hwid or ""
        is_esp = False

        if p.vid == 0x303A and p.pid == 0x1001:
            is_esp = True
        elif p.vid == 0x303A:
            is_esp = True
        elif "303A:1001" in hwid or "USB Serial" in desc or "usbmodem" in p.device:
            is_esp = True

        if is_esp:
            esp_ports.append(p)

    results: List[BoardInfoResult] = []
    for p in esp_ports:
        results.append(probe_single_port(p, timeout_s=timeout_s))

    return results


def auto_detect_port(need_cap: int = 0, preferred_model: Optional[str] = None) -> str:
    """Find the best matching active ESP32-S3 serial port, or raise RuntimeError."""
    boards = detect_boards(timeout_s=1.8)

    if not boards:
        raise RuntimeError(
            "No ESP32-S3 boards detected.\n"
            "Troubleshooting tips:\n"
            "  1. Ensure the board is plugged in with a USB-C data cable (avoid charge-only cables).\n"
            "  2. Check Device Manager (Windows) or 'ls /dev/cu.usb*' (macOS).\n"
            "  3. Try running: robotos flash-firmware"
        )

    # 1. Filter by requested capability
    candidates = boards
    if need_cap:
        cap_matched = [b for b in candidates if b.status == "ready" and (b.caps & need_cap)]
        if cap_matched:
            candidates = cap_matched

    # 2. Filter by preferred model
    if preferred_model:
        model_matched = [b for b in candidates if b.model.lower() == preferred_model.lower()]
        if model_matched:
            candidates = model_matched

    # 3. Filter by ready status
    ready = [b for b in candidates if b.status == "ready"]
    if ready:
        candidates = ready

    if len(candidates) == 1:
        chosen = candidates[0]
        print(f"   [auto-detect] Selected ESP32-S3 board on {chosen.port} ({chosen.model}, {chosen.caps_str})")
        return chosen.port

    # If multiple boards are attached, pick the first ready one and inform user
    chosen = candidates[0]
    print(f"   [auto-detect] Multiple boards found ({len(candidates)}). Using {chosen.port} ({chosen.model}).")
    print(f"                 (To specify a different port, pass --port <PORT>)")
    return chosen.port


def print_detection_report(boards: List[BoardInfoResult]):
    """Print formatted terminal report for detected boards."""
    print("============================================================")
    print(" RobotOS Board Auto-Detection & Wire Handshake Scanner")
    print("============================================================")

    if not boards:
        print("\n[warning] No ESP32-S3 boards detected on this computer.")
        print("\nTroubleshooting tips:")
        print("  1. Connect your board using a USB-C data cable (avoid charge-only cables).")
        print("  2. If the board has power but doesn't enumerate, hold BOOT and click RESET.")
        print("  3. Windows: Check Device Manager under 'Ports (COM & LPT)'.")
        print("  4. macOS: Run 'ls /dev/cu.usb*' in Terminal.")
        print("============================================================\n")
        return

    print(f"\nFound {len(boards)} ESP32-S3 serial device(s):\n")

    for i, b in enumerate(boards, start=1):
        status_tag = {
            "ready": "✓ READY & STREAMING",
            "busy": "⚠ PORT LOCKED / BUSY",
            "unflashed": "⚡ UNFLASHED / NON-WORKSHOP FIRMWARE",
            "error": "✗ ERROR",
        }.get(b.status, b.status.upper())

        print(f"[{i}] Port: {b.port} ({b.description})")
        print(f"    • Hardware:      ESP32-S3 (VID: {hex(b.vid) if b.vid else 'None'}, PID: {hex(b.pid) if b.pid else 'None'})")
        print(f"    • Wire Protocol: {status_tag}")
        if b.status == "ready":
            print(f"    • Board Model:   {b.model} ({'Waveshare Touch LCD 2.8' if b.model == 'ws28p' else 'Audio Board'})")
            print(f"    • Capabilities:  {b.caps_str}")
            if b.uuid:
                print(f"    • Board UUID:    {b.uuid}")
            if b.fw_version:
                print(f"    • Firmware ID:   {b.fw_version}")
            print(f"    • Live Sensor:   {b.sensor_preview}")
            print(f"    • Next Command:  {b.suggested_command}")
        elif b.status == "unflashed":
            print(f"    • Notice:        {b.sensor_preview}")
            print(f"    • Solution:      Flash prebuilt workshop firmware:")
            print(f"                     robotos flash-firmware --port {b.port} --board ws28p")
        elif b.status == "busy":
            print(f"    • Notice:        {b.sensor_preview}")
            print(f"    • Fix:           {b.troubleshooting}")
        else:
            print(f"    • Error Details: {b.sensor_preview}")
            if b.troubleshooting:
                print(f"    • Fix:           {b.troubleshooting}")
        print()

    ready_count = sum(1 for b in boards if b.status == "ready")
    print("============================================================")
    if ready_count > 0:
        print(f" ✓ {ready_count} board(s) verified with live handshake and ready for labs!")
    else:
        print(" ⚡ To flash your board, run: robotos flash-firmware")
    print("============================================================\n")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="robotos detect",
        description="Auto-detect connected RobotOS ESP32-S3 boards and probe wire protocol telemetry.",
    )
    parser.add_argument("--json", action="store_true", help="Output results as JSON for scripting")
    parser.add_argument("--timeout", type=float, default=2.0, help="Probe timeout in seconds (default: 2.0)")
    args = parser.parse_args(argv)

    boards = detect_boards(timeout_s=args.timeout)

    if args.json:
        data = [asdict(b) for b in boards]
        print(json.dumps(data, indent=2))
        return 0

    print_detection_report(boards)
    return 0 if any(b.status == "ready" for b in boards) else (0 if boards else 1)


if __name__ == "__main__":
    sys.exit(main())
