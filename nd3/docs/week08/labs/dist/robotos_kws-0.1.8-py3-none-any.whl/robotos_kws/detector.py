"""Real-time sliding-window and single-clip KWS detector for robotos_kws."""
from __future__ import annotations

import time
from collections import deque
from pathlib import Path
from typing import Dict, Generator, Optional, Tuple, Union

import numpy as np

import kws_common as kc


class Detector:
    """Keyword Spotting Detector powered by TensorFlow Lite.
    
    Supports both float32 and int8 models, single-clip prediction, and live streaming.
    """

    def __init__(self, model_path: Union[str, Path], threshold: float = 0.75,
                 refractory_ms: int = 1000, smooth: int = 3):
        self.model_path = Path(model_path)
        if not self.model_path.exists():
            raise FileNotFoundError(f"Model file not found: {self.model_path}")

        self.interpreter = kc.make_interpreter(str(self.model_path))
        self.threshold = threshold
        self.refractory_ms = refractory_ms
        self.refractory_samples = int(kc.SAMPLE_RATE * refractory_ms / 1000)
        self.smooth = smooth
        self.labels = kc.LABELS
        self.keywords = kc.KEYWORDS

    def predict_proba(self, audio: Union[str, Path, np.ndarray]) -> Dict[str, float]:
        """Compute softmax probability distribution over all classes for a 1.0 s audio clip."""
        if isinstance(audio, (str, Path)):
            pcm = kc.read_wav(audio)
        else:
            pcm = np.asarray(audio, dtype=np.int16).reshape(-1)

        clip = kc.center_on_energy(pcm, kc.CLIP_SAMPLES)
        feats = kc.log_mel(clip)
        probs = kc.run_tflite(self.interpreter, feats)
        return {lb: float(probs[i]) for i, lb in enumerate(self.labels)}

    def predict(self, audio: Union[str, Path, np.ndarray]) -> Tuple[str, float]:
        """Predict the top class and its confidence for a 1.0 s audio clip."""
        dist = self.predict_proba(audio)
        top_label = max(dist, key=dist.get)
        return top_label, dist[top_label]

    def stream_pc(self, device: Optional[int | str] = None,
                  hop_ms: int = 250,
                  threshold: Optional[float] = None) -> Generator[Tuple[str, float, float], None, None]:
        """Stream audio from PC microphone and yield (keyword, confidence, timestamp) events."""
        try:
            import sounddevice as sd
        except ImportError:
            raise RuntimeError("sounddevice is required for PC mic streaming. Run: pip install sounddevice")

        import queue
        q: queue.Queue[np.ndarray] = queue.Queue()
        block_samples = int(kc.SAMPLE_RATE * hop_ms / 1000)

        def callback(indata, frames, time_info, status):
            q.put(indata[:, 0].copy())

        thresh = threshold if threshold is not None else self.threshold
        ring = np.zeros(kc.CLIP_SAMPLES, dtype=np.int16)
        history = deque(maxlen=self.smooth)
        since_detection = self.refractory_samples
        samples_seen = 0

        stream = sd.InputStream(samplerate=kc.SAMPLE_RATE, blocksize=block_samples,
                                device=device, channels=1, dtype="int16", callback=callback)
        with stream:
            while True:
                block = q.get()
                ring = np.concatenate([ring[len(block):], block])
                samples_seen += len(block)
                since_detection += len(block)

                feats = kc.log_mel(ring)
                probs = kc.run_tflite(self.interpreter, feats)
                history.append(probs)
                avg = np.mean(history, axis=0)
                top = int(np.argmax(avg))
                label, score = self.labels[top], float(avg[top])

                current_thresh = threshold if threshold is not None else self.threshold
                if label in self.keywords and score >= current_thresh and since_detection >= self.refractory_samples:
                    since_detection = 0
                    t_event = samples_seen / kc.SAMPLE_RATE
                    yield label, score, t_event

    def stream_board(self, port: str, gain: int = 80,
                     hop_ms: int = 250,
                     threshold: Optional[float] = None) -> Generator[Tuple[str, float, float], None, None]:
        """Stream audio from ES3C28P board over USB and yield (keyword, confidence, timestamp) events."""
        from robotos_kws.board import Board

        thresh = threshold if threshold is not None else self.threshold
        ring = np.zeros(kc.CLIP_SAMPLES, dtype=np.int16)
        history = deque(maxlen=self.smooth)
        since_detection = self.refractory_samples
        samples_seen = 0
        hop_samples = int(kc.SAMPLE_RATE * hop_ms / 1000)
        accum = []
        accum_len = 0

        with Board(port=port, gain=gain) as board:
            for chunk in board.stream_audio():
                accum.append(chunk)
                accum_len += len(chunk)
                if accum_len >= hop_samples:
                    block = np.concatenate(accum)
                    accum = []
                    accum_len = 0

                    ring = np.concatenate([ring[len(block):], block])
                    samples_seen += len(block)
                    since_detection += len(block)

                    feats = kc.log_mel(ring)
                    probs = kc.run_tflite(self.interpreter, feats)
                    history.append(probs)
                    avg = np.mean(history, axis=0)
                    top = int(np.argmax(avg))
                    label, score = self.labels[top], float(avg[top])

                    current_thresh = threshold if threshold is not None else self.threshold
                if label in self.keywords and score >= current_thresh and since_detection >= self.refractory_samples:
                        since_detection = 0
                        t_event = samples_seen / kc.SAMPLE_RATE
                        yield label, score, t_event
