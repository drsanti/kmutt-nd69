"""Board connection and audio streaming utilities for robotos_kws."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Generator, Optional, Tuple

import numpy as np

import kws_common as kc
import wire


class Board:
    """Manages serial connection and microphone interaction with an ES3C28P workshop board."""

    def __init__(self, port: Optional[str] = None, gain: int = 80, baudrate: int = 115200):
        if port is None:
            import detect_board
            port = detect_board.auto_detect_port(need_cap=wire.CAP_MIC, preferred_model="es3c28p")
        self.port = port
        self.gain = gain
        self.baudrate = baudrate
        self.session: Optional[wire.BoardSession] = None
        self.info: Optional[wire.BoardInfo] = None

    def __enter__(self) -> Board:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def connect(self) -> None:
        """Open the serial port and verify board identity and MIC capability."""
        if self.session is not None:
            return
        self.session = wire.BoardSession.open(self.port)
        wire.require_cap(self.session, wire.CAP_MIC, "Board")
        self.info = self.session.board_info
        self.session.mic_enable(True, gain_pct=self.gain)

    def close(self) -> None:
        """Disable microphone and close serial connection."""
        if self.session is not None:
            try:
                self.session.mic_stream(False)
                self.session.mic_enable(False)
            except Exception:
                pass
            finally:
                self.session.close()
                self.session = None

    def get_info(self) -> wire.BoardInfo:
        """Return the BoardInfo received during handshake."""
        if self.session is None:
            self.connect()
        return self.info

    def measure_level(self, seconds: float = 1.0) -> Tuple[float, int]:
        """Record audio for the given duration and return (rms_dbfs, peak_amplitude)."""
        clip = self.record_clip(seconds=seconds)
        rms = kc.rms_dbfs(clip)
        peak = int(np.max(np.abs(clip.astype(np.int32)))) if len(clip) else 0
        return rms, peak

    def record_clip(self, seconds: float = 1.0, max_lost: int = 35) -> np.ndarray:
        """Record audio from the board MEMS mic and return 16 kHz int16 samples.
        
        If seq lost chunks exceed max_lost, an exception is raised.
        """
        if self.session is None:
            self.connect()

        asm = wire.PcmAssembler(target_rate=kc.SAMPLE_RATE, board_rate=wire.MIC_RATE_HZ)
        n_target = int(seconds * kc.SAMPLE_RATE)
        self.session.mic_stream(True)
        t_deadline = time.time() + seconds + 2.0
        try:
            while len(asm.pcm) < n_target and time.time() < t_deadline:
                fr = self.session.read_frame()
                if isinstance(fr, wire.MicPcm):
                    asm.feed(fr.seq, fr.pcm)
        finally:
            self.session.mic_stream(False)

        if asm.lost > max_lost:
            raise RuntimeError(f"Too many chunks lost on USB: {asm.lost} > {max_lost}")

        return asm.pcm[:n_target]

    def stream_audio(self) -> Generator[np.ndarray, None, None]:
        """Stream raw int16 PCM chunks continuously as they arrive from the board."""
        if self.session is None:
            self.connect()

        self.session.mic_stream(True)
        try:
            while True:
                fr = self.session.read_frame()
                if isinstance(fr, wire.MicPcm):
                    yield fr.pcm
        finally:
            self.session.mic_stream(False)
