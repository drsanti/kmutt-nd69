"""PC Microphone recording and device utilities for robotos_kws."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Tuple, Optional

import numpy as np

import kws_common as kc


def list_devices() -> List[str]:
    """Return a formatted list of all audio input devices."""
    try:
        import sounddevice as sd
    except ImportError:
        raise RuntimeError("sounddevice is not installed. Run: pip install sounddevice")
    
    devices = sd.query_devices()
    res = []
    for idx, d in enumerate(devices):
        if d.get("max_input_channels", 0) > 0:
            res.append(f"{idx:3d}: {d['name']} ({d['max_input_channels']} in)")
    return res


def print_devices() -> None:
    """Print the available audio input devices to stdout."""
    try:
        import sounddevice as sd
    except ImportError:
        print("[error] sounddevice is not installed. Run: pip install sounddevice")
        return
    print(sd.query_devices())


class AudioRecorder:
    """Records calibrated 16 kHz mono 16-bit PCM clips from a computer microphone."""

    def __init__(self, device: Optional[int | str] = None, sample_rate: int = kc.SAMPLE_RATE):
        self.device = device
        self.sample_rate = sample_rate

    def record(self, seconds: float = 1.0) -> np.ndarray:
        """Record audio for the specified number of seconds and return int16 PCM samples."""
        try:
            import sounddevice as sd
        except ImportError:
            raise RuntimeError("sounddevice is not installed. Run: pip install sounddevice")

        n_samples = int(seconds * self.sample_rate)
        audio = sd.rec(n_samples, samplerate=self.sample_rate, channels=1, dtype="int16", device=self.device)
        sd.wait()
        return np.asarray(audio, dtype=np.int16).reshape(-1)

    def record_and_save(self, path: str | Path, seconds: float = 1.0) -> Path:
        """Record audio and save directly to a 16 kHz mono 16-bit WAV file."""
        pcm = self.record(seconds=seconds)
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        kc.write_wav(path, pcm)
        return path
