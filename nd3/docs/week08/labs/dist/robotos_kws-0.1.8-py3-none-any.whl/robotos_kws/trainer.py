"""Programmatic Model Training and Evaluation for robotos_kws."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

import evaluate as eval_script
import kws_common as kc
import train as train_script


class Trainer:
    """Manages DS-CNN training, int8 post-training quantization, and model benchmarking."""

    def __init__(self, data_dir: Union[str, Path] = "dataset", out_dir: Union[str, Path] = "artifacts"):
        self.data_dir = self._resolve_data_dir(Path(data_dir))
        self.out_dir = Path(out_dir)

    @classmethod
    def _resolve_data_dir(cls, target: Path) -> Path:
        """Resolve dataset directory or synthesize a test dataset if none exists."""
        # 1. If target directly exists and contains clips
        if target.exists() and kc.scan_dataset(target, strict=False):
            return target

        # 2. Walk up parent hierarchy to find dataset or synth_dataset
        cwd = Path.cwd().resolve()
        search_dirs = [cwd] + list(cwd.parents)[:6]
        for parent in search_dirs:
            for cand in [
                parent / "dataset",
                parent / "synth_dataset",
                parent / "python" / "dataset",
                parent / "nd1" / "docs" / "week08" / "labs" / "python" / "dataset",
                parent / "kmutt-nd69" / "nd1" / "docs" / "week08" / "labs" / "python" / "dataset",
            ]:
                if cand.is_dir() and kc.scan_dataset(cand, strict=False):
                    print(f"[robotos_kws] Auto-resolved dataset directory to: {cand.resolve()}")
                    return cand

        # 3. If no dataset found anywhere, synthesize small dataset in synth_dataset
        default_synth = (cwd / "synth_dataset").resolve()
        print(f"[robotos_kws] No audio clips found in '{target}'.")
        print(f"[robotos_kws] Auto-generating synthetic dataset in '{default_synth}' (30 clips/class)...")
        import make_synthetic_dataset
        make_synthetic_dataset.main(["--out", str(default_synth), "--per-class", "30", "--speakers", "4"])
        return default_synth

    def train(self, epochs: int = 40, batch: int = 64, augment: int = 2,
              width: int = 32, seed: int = 42) -> Dict[str, Any]:
        """Train the model and save artifacts (model.keras, model_float.tflite, model_int8.tflite, meta.json)."""
        args = [
            "--data", str(self.data_dir),
            "--out", str(self.out_dir),
            "--epochs", str(epochs),
            "--batch", str(batch),
            "--augment", str(augment),
            "--width", str(width),
            "--seed", str(seed),
        ]
        rc = train_script.main(args)
        if rc != 0:
            raise RuntimeError(f"Training failed with exit code {rc}")
        meta_path = self.out_dir / "meta.json"
        return json.loads(meta_path.read_text()) if meta_path.exists() else {}

    def evaluate(self, split: str = "test", device: Optional[str] = None) -> int:
        """Run evaluation on the test split and generate report.md."""
        args = [
            "--artifacts", str(self.out_dir),
            "--data", str(self.data_dir),
            "--split", split,
        ]
        if device:
            args.extend(["--device", device])
        return eval_script.main(args)
