"""Entry point for `python -m robotos_kws`."""
from __future__ import annotations

import sys
from robotos_kws.cli import main

if __name__ == "__main__":
    sys.exit(main() or 0)
