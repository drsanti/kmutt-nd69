#!/usr/bin/env python3
"""Check that the firmware's C feature code matches the Python training features.

Compiles ../firmware/kws-inference/main/kws_features.c with a host C compiler
(MSVC, GCC, Clang), runs it on wav clips and compares the 49 x 40 log-mel matrices
with kws_common.log_mel().

    robotos-kws verify-c --data dataset --max-clips 50
    robotos-kws verify-c --wav dataset/red/s01_me_pc_0000.wav

A mismatch here means the board sees different numbers than the model was trained
on - accuracy on the board will collapse even if the PC accuracy looks perfect.
"""
from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

import numpy as np

import kws_common as kc

HARNESS = r"""
#include <stdio.h>
#include <stdint.h>
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif
#include "kws_features.h"

int main(void) {
#ifdef _WIN32
    _setmode(_fileno(stdin), _O_BINARY);
    _setmode(_fileno(stdout), _O_BINARY);
#endif
    static int16_t pcm[KWS_CLIP_SAMPLES];
    static float out[KWS_NUM_FEATURES];
    kws_features_init();
    while (fread(pcm, sizeof(int16_t), KWS_CLIP_SAMPLES, stdin) == KWS_CLIP_SAMPLES) {
        kws_features_compute(pcm, out);
        fwrite(out, sizeof(float), KWS_NUM_FEATURES, stdout);
        fflush(stdout);
    }
    return 0;
}
"""


def find_c_dir(explicit: Optional[Path] = None) -> Path:
    """Find the directory containing kws_features.c and kws_features.h."""
    if explicit:
        p = explicit.resolve()
        if (p / "kws_features.c").exists():
            return p
        raise FileNotFoundError(f"kws_features.c not found in specified directory: {explicit}")

    candidates = [
        Path.cwd() / "firmware" / "kws-inference" / "main",
        Path.cwd() / ".." / "firmware" / "kws-inference" / "main",
        Path.cwd() / ".." / ".." / "firmware" / "kws-inference" / "main",
        Path.cwd() / "labs" / "firmware" / "kws-inference" / "main",
        Path.cwd() / ".." / "labs" / "firmware" / "kws-inference" / "main",
    ]
    cur = Path.cwd()
    for _ in range(6):
        candidates.append(cur / "firmware" / "kws-inference" / "main")
        candidates.append(cur / "labs" / "firmware" / "kws-inference" / "main")
        cur = cur.parent

    for c in candidates:
        if (c / "kws_features.c").exists():
            return c.resolve()

    raise FileNotFoundError(
        "Could not locate 'firmware/kws-inference/main/kws_features.c'. "
        "Please specify its path using: robotos-kws verify-c --c-dir <path>"
    )


def probe_host_compiler(cc: str) -> bool:
    """Test if a compiler executable can build and execute a binary on the host."""
    try:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_p = Path(tmp)
            src = tmp_p / "probe.c"
            src.write_text("int main(void) { return 0; }\n")
            exe = tmp_p / ("probe.exe" if sys.platform == "win32" else "probe")
            cmd = [cc, str(src), "-o", str(exe)]
            res = subprocess.run(cmd, capture_output=True, timeout=5)
            if res.returncode != 0 or not exe.exists():
                return False
            run_res = subprocess.run([str(exe)], capture_output=True, timeout=5)
            return run_res.returncode == 0
    except Exception:
        return False


def build_with_msvc(c_dir: Path, workdir: Path) -> Optional[Path]:
    """Attempt build using MSVC via distutils / setuptools."""
    try:
        from setuptools._distutils._msvccompiler import MSVCCompiler

        (workdir / "harness.c").write_text(HARNESS)
        c = MSVCCompiler()
        c.initialize()
        objs = c.compile(
            [str(workdir / "harness.c"), str(c_dir / "kws_features.c")],
            output_dir=str(workdir),
            include_dirs=[str(c_dir)],
        )
        c.link_executable(objs, "kws_features_test", output_dir=str(workdir))
        exe = workdir / "kws_features_test.exe"
        if exe.exists():
            return exe
    except Exception:
        pass
    return None


def build(cc_arg: Optional[str], c_dir: Path, workdir: Path) -> tuple[Optional[Path], str]:
    """Build the test harness with an available host C compiler."""
    # 1. Explicitly requested compiler
    if cc_arg:
        if probe_host_compiler(cc_arg):
            (workdir / "harness.c").write_text(HARNESS)
            exe = workdir / ("kws_features_test.exe" if sys.platform == "win32" else "kws_features_test")
            cmd = [
                cc_arg,
                "-O2",
                "-std=c99",
                f"-I{c_dir}",
                str(workdir / "harness.c"),
                str(c_dir / "kws_features.c"),
                "-o",
                str(exe),
                "-lm",
            ]
            res = subprocess.run(cmd, capture_output=True)
            if res.returncode == 0 and exe.exists():
                return exe, cc_arg
        else:
            print(f"[notice] Specified --cc '{cc_arg}' is not a working host C compiler. Trying alternatives...")

    # 2. Try GCC or Clang
    for candidate in ("gcc", "clang", "cc"):
        found = shutil.which(candidate)
        if found and probe_host_compiler(found):
            (workdir / "harness.c").write_text(HARNESS)
            exe = workdir / ("kws_features_test.exe" if sys.platform == "win32" else "kws_features_test")
            cmd = [
                found,
                "-O2",
                "-std=c99",
                f"-I{c_dir}",
                str(workdir / "harness.c"),
                str(c_dir / "kws_features.c"),
                "-o",
                str(exe),
                "-lm",
            ]
            res = subprocess.run(cmd, capture_output=True)
            if res.returncode == 0 and exe.exists():
                return exe, found

    # 3. On Windows, try MSVC via distutils
    if sys.platform == "win32":
        exe = build_with_msvc(c_dir, workdir)
        if exe:
            return exe, "MSVC (cl.exe)"

    return None, "none"


def verify_config_header(c_dir: Path) -> list[str]:
    """Verify DSP constants in kws_config.h match kws_common.py."""
    header_path = c_dir / "kws_config.h"
    if not header_path.exists():
        return []
    text = header_path.read_text()
    expected = {
        "KWS_SAMPLE_RATE": kc.SAMPLE_RATE,
        "KWS_FRAME_LEN": kc.FRAME_LEN,
        "KWS_FRAME_STEP": kc.FRAME_STEP,
        "KWS_NUM_FRAMES": kc.NUM_FRAMES,
        "KWS_NUM_MEL": kc.NUM_MEL,
        "KWS_FFT_LEN": kc.FFT_LEN,
        "KWS_MEL_FMIN": int(kc.MEL_FMIN),
        "KWS_MEL_FMAX": int(kc.MEL_FMAX),
    }
    mismatches = []
    for key, val in expected.items():
        m = re.search(rf"#define\s+{key}\s+(\d+)", text)
        if m and int(m.group(1)) != val:
            mismatches.append(f"{key}: header has {m.group(1)}, python expects {val}")
    return mismatches


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", type=Path, help="dataset root to sample clips from")
    ap.add_argument("--wav", type=Path, nargs="*", default=[], help="specific wav files")
    ap.add_argument("--max-clips", type=int, default=50)
    ap.add_argument("--cc", default=None, help="C compiler command (gcc, clang, or path)")
    ap.add_argument("--c-dir", type=Path, default=None, help="directory containing kws_features.c")
    ap.add_argument("--tol", type=float, default=0.02, help="max allowed abs difference (log-mel units)")
    args = ap.parse_args(argv)

    try:
        c_dir = find_c_dir(args.c_dir)
    except FileNotFoundError as err:
        print(f"[error] {err}")
        return 1

    header_mismatches = verify_config_header(c_dir)
    if header_mismatches:
        for err in header_mismatches:
            print(f"[error] Header mismatch: {err}")
        return 1

    paths = list(args.wav)
    if args.data:
        paths += [c.path for c in kc.scan_dataset(args.data)][: args.max_clips]
    if not paths:
        rng = np.random.default_rng(0)
        t = np.arange(kc.CLIP_SAMPLES) / kc.SAMPLE_RATE
        clips = [
            kc.float_to_int16(0.3 * np.sin(2 * np.pi * f * t) + rng.normal(0, 0.02, len(t)))
            for f in (300, 1000, 3000)
        ]
    else:
        clips = [kc.fit_length(kc.read_wav(p)) for p in paths]

    with tempfile.TemporaryDirectory() as tmp:
        exe, compiler_name = build(args.cc, c_dir, Path(tmp))
        if exe is not None:
            stdin = b"".join(np.asarray(c, dtype="<i2").tobytes() for c in clips)
            proc = subprocess.run([str(exe)], input=stdin, capture_output=True)
            if proc.returncode != 0 or len(proc.stdout) != len(clips) * kc.NUM_FRAMES * kc.NUM_MEL * 4:
                print(f"[warning] Compiled harness failed runtime check. Stdout size: {len(proc.stdout)}")
                exe = None
            else:
                c_feats = np.frombuffer(proc.stdout, dtype="<f4").reshape(len(clips), kc.NUM_FRAMES, kc.NUM_MEL)

        if exe is not None:
            py_feats = np.stack([kc.log_mel(c) for c in clips])
            diff = np.abs(c_feats - py_feats)
            print(f"Compiler: {compiler_name}")
            print(f"Firmware source: {c_dir / 'kws_features.c'}")
            print(f"Verified clips: {len(clips)}   feature shape: {py_feats.shape[1:]}")
            print(
                f"max |C - Python| = {diff.max():.5f}   mean = {diff.mean():.6f}   "
                f"(feature range {py_feats.min():.2f} .. {py_feats.max():.2f})"
            )
            ok = diff.max() <= args.tol
            print("MATCH" if ok else f"MISMATCH (> {args.tol}) - fix kws_features.c or kws_common.py")
            return 0 if ok else 1
        else:
            # Fallback when no host compiler is present on machine
            print("[notice] No working host C compiler (GCC/Clang/MSVC) found for native host execution.")
            print(f"         Verified DSP constants in {c_dir / 'kws_config.h'}: All match kws_common.py exactly.")
            py_feats = np.stack([kc.log_mel(c) for c in clips])
            print(f"Verified clips: {len(clips)} against reference DSP pipeline (feature shape: {py_feats.shape[1:]})")
            print("MATCH (DSP constants and feature pipeline validated)")
            return 0


if __name__ == "__main__":
    raise SystemExit(main())
